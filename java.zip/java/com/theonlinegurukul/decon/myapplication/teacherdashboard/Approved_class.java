package com.theonlinegurukul.decon.myapplication.teacherdashboard;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.theonlinegurukul.decon.myapplication.R;
import com.theonlinegurukul.decon.myapplication.helper.SQLiteHandler;
import com.theonlinegurukul.decon.myapplication.helper.SessionManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static com.theonlinegurukul.decon.myapplication.app.AppConfig.REGISTER_URL;

/*
import static com.theonlinegurukul.decon.myapplication.helper.SQLiteHandler.UID;
*/

public class Approved_class extends AppCompatActivity {
    private SQLiteHandler db;
    SessionManager session;
    Button buttSearch;
    ListView listview1;
    private Button buttonRegister;
    Spinner spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_approved_class);
        setTitle("Approved Subject");
        db = new SQLiteHandler(this);
        listview1 = (ListView) findViewById(R.id.listview);

        db.addTeacherdashboard("ew","eww","wer","ytr","uyt","ytr","yrr",
                "ty","utr","utt","utt","utt","yrr"
        ,"rrrf","trr" ,"hrr");
        ListView listView = (ListView) findViewById(R.id.listview);
        ArrayList<String> theList = new ArrayList<>();
        Cursor data = db.getListContents();
        if (data.getCount() == 0) {
            Toast.makeText(getApplicationContext(), "There are no contents in this list!", Toast.LENGTH_LONG).show();
        } else {
            data.moveToFirst();
            theList.add("\nCATEGORY" + "\t\t\t : " + data.getString(1) + "\nCLASS" + "\t\t\t : " + data.getString(2)
                    + "\nSUBJECT" + "\t\t\t : " + data.getString(3) + "\nSUBJECT_CODE" + "\t\t\t : " + data.getString(4) + "\n"
                    + "CLASS_ID" + "\t\t\t : " + data.getString(5) + "\nCLASS_DATE" + "\t\t\t : " + data.getString(7) + "\n"
                    + "COURSE_START_DATE" + "\t\t\t : " + data.getString(8) + "COURSE_END_DATE" + "\t\t\t : " + data.getString(8)
                    + "CLASS_START_TIME" + "\t\t\t : " + data.getString(8) + "CLASS_END_TIME" + "\t\t\t : " + data.getString(8)
                    + "CLASS_DURATION_MIN" + "\t\t\t : " + data.getString(8) + "CLASS_EXTENDED_TIME_MIN" + "\t\t\t : " + data.getString(8)
                    + "FACULTY_CODE" + "\t\t\t : " + data.getString(8) + "COURSE_ID" + "\t\t\t : " + data.getString(8)
                    + "TIME_ZONE" + "\t\t\t : " + data.getString(8) + "TOTAL_EARN" + "\t\t\t : " + data.getString(8));

            ListAdapter listAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, theList);
            listView.setCacheColorHint(Color.rgb(36, 33, 32));
            listView.setBackgroundColor(Color.rgb(192, 192, 192));
            listView.setAdapter(listAdapter);


            buttonRegister = (Button) findViewById(R.id.submit);

            buttonRegister.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (view == buttonRegister) {
                        registerUser();
                    }
                }

                private void registerUser() {
                    String listview = listview1.toString().trim().toLowerCase();
                    register(listview);
                }

                private void register(final String listview) {

                    StringRequest stringRequest = new StringRequest(Request.Method.POST, REGISTER_URL,
                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    // Log.i("check:", response.toString());
                                    // Log.i("Responseparse","Yes");

                                    Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();

                                }
                            },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
                                }
                            }) {
                        @Override
                        protected Map<String, String> getParams() throws AuthFailureError {
                            Map<String, String> map = new HashMap<String, String>();
                            map.put("listview", listview);
                            return map;
                        }
                    };

                    RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
                    requestQueue.add(stringRequest);
                }
            });
        }
    }
}
