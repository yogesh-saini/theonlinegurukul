package com.theonlinegurukul.decon.myapplication.teacherdashboard;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.theonlinegurukul.decon.myapplication.R;

public class Recent_class extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recent_class);
        setTitle("Recent Classes");
    }
}
