package com.theonlinegurukul.decon.myapplication.teacherdashboard;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.TextView;

import com.theonlinegurukul.decon.myapplication.R;

public class Pop_up extends AppCompatActivity {
    Dialog dialog;
    CardView elevnth, twelfth;
    TextView close;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pop_up);

        dialog = new Dialog(this);
        elevnth = (CardView) findViewById(R.id.elevnth);
        twelfth = (CardView) findViewById(R.id.twelfth);
        elevnth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ShowPositiviPopup();
            }
        });

        twelfth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ShowPopup();
            }
        });
    }

    public void ShowPositiviPopup() {
        dialog.setContentView(R.layout.activity_sbse);
        dialog.setContentView(R.layout.activity_sbse);
        close = (TextView) dialog.findViewById(R.id.close);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();

    }

    public void ShowPopup() {
        dialog.setContentView(R.layout.activity_sbse);
        close = (TextView) dialog.findViewById(R.id.close);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();
    }
}
