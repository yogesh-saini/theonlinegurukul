package com.theonlinegurukul.decon.myapplication.teacherdashboard;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.theonlinegurukul.decon.myapplication.R;

public class Alloted_courses extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Alloted_Subject");
        setContentView(R.layout.activity_alloted_courses);
    }
}
