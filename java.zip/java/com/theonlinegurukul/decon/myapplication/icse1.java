package com.theonlinegurukul.decon.myapplication;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.theonlinegurukul.decon.myapplication.teacherdashboard.Approved_class;

public class icse1 extends AppCompatActivity {

    Dialog dialog;
    CardView eigth, ninth, tenth,elevnth, twelfth;;
    TextView close;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_icse);
        setTitle("Academics");

        dialog = new Dialog(this);
        eigth = (CardView) findViewById(R.id.eigth);
        ninth = (CardView) findViewById(R.id.ninth);
        tenth = (CardView) findViewById(R.id.tenth);
        elevnth = (CardView) findViewById(R.id.elevnth);
        twelfth = (CardView) findViewById(R.id.twelfth);

        eigth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ShowPositiviPopup();
            }
        });

        ninth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ShowPopup();

            }
        });
        tenth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ShowPositiv();
            }
        });

        elevnth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Show();

            }
        });



       twelfth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ShowPop();

            }
        });

    }

    public void ShowPositiviPopup() {
        dialog.setContentView(R.layout.activity_sbse);
        dialog.setContentView(R.layout.activity_sbse);
        close = (TextView) dialog.findViewById(R.id.close);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();

    }
    public void ShowPopup() {
        dialog.setContentView(R.layout.activity_sbse);
        close = (TextView) dialog.findViewById(R.id.close);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();
     }
    public void ShowPositiv() {
        dialog.setContentView(R.layout.activity_sbse);
        dialog.setContentView(R.layout.activity_sbse);
        close = (TextView) dialog.findViewById(R.id.close);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();

    }
    public void Show() {
        dialog.setContentView(R.layout.activity_pop_up);

        close = (TextView) dialog.findViewById(R.id.close);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();


    }
    public void ShowPop() {
        dialog.setContentView(R.layout.activity_pop_up);

        close = (TextView) dialog.findViewById(R.id.close);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();

    }



}






/*

    public void ShowPopup(View v) {
        TextView close;
        dialog.setContentView(R.layout.activity_sbse);


     close =(TextView) findViewById(R.id.close);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
    dialog.show();
    }
}
*/


/*
            @Override
            public void onClick(View view) {
                ShowPositivePopup();
            }


    private void ShowPositivePopup() {
        dialog.setContentView(R.layout.activity_sbse);

    }
});
    }
}
*/



