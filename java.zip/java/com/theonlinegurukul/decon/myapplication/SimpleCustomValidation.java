package com.theonlinegurukul.decon.myapplication;

/**
 * Created by Decon on 7/3/2018.
 */

interface SimpleCustomValidation {
boolean compare(String input);
}
