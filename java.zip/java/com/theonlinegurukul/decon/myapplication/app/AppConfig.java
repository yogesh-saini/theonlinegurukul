package com.theonlinegurukul.decon.myapplication.app;

public class AppConfig {

	public static final String REGISTER_URL = "http://203.122.21.147/attendance/index.php/cron/test_30";

}