package com.theonlinegurukul.decon.myapplication;

import android.app.Activity;
import android.app.DownloadManager;
import android.graphics.Color;
import android.os.Bundle;
import android.renderscript.Sampler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SearchView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationHolder;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.basgeekball.awesomevalidation.utility.RegexTemplate;
import com.google.android.gms.common.api.Response;
import com.google.common.collect.Range;
import com.theonlinegurukul.decon.myapplication.fragment.Qualification;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import static android.content.ContentValues.TAG;
import static android.view.View.*;
import static com.basgeekball.awesomevalidation.ValidationStyle.BASIC;
import static com.basgeekball.awesomevalidation.ValidationStyle.COLORATION;
import static com.basgeekball.awesomevalidation.ValidationStyle.UNDERLABEL;


public class Basic_info extends Fragment implements OnClickListener,AdapterView.OnItemSelectedListener {

    private AwesomeValidation mAwesomeValidation;
    private EditText editTextName;
    private EditText editTextLName;
    private Spinner spinnerText;
    private EditText Phone;
    private EditText Email;
    private EditText Password;
    private EditText Cpassword;
    private EditText dob;
    private EditText Adhar;
    private Spinner Spinner1;
    private Spinner Spinner2;
    private Spinner Spinner3;
    private EditText Zip;
    private Button next;
    private static final String REGISTER_URL = "http://203.122.21.147/attendance/index.php/cron/test_30";
    private AwesomeValidation awesomeValidation;
    private Spinner spinner;

    public Basic_info() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        final View v = inflater.inflate(R.layout.fragment_basic_info, container, false);


        //  mAwesomeValidation.addValidation(editTextName, "regex", "Error info");

        editTextName = (EditText) v.findViewById(R.id.Name);
        editTextLName = (EditText) v.findViewById(R.id.LName);
        spinnerText = (Spinner) v.findViewById(R.id.spinner);
        Phone = (EditText) v.findViewById(R.id.phone);
        Email = (EditText) v.findViewById(R.id.email);
        Password = (EditText) v.findViewById(R.id.password);
        Cpassword = (EditText) v.findViewById(R.id.cpassword);
        dob = (EditText) v.findViewById(R.id.DOB);
        Adhar = (EditText) v.findViewById(R.id.adhar);
        Spinner1 = (Spinner) v.findViewById(R.id.spinner1);
        Spinner2 = (Spinner) v.findViewById(R.id.spinner2);
        Spinner3 = (Spinner) v.findViewById(R.id.spinner3);
        Zip = (EditText) v.findViewById(R.id.zip);

        next = (Button) v.findViewById(R.id.next);
        final ViewPager pager = (ViewPager) getActivity().findViewById(R.id.container);
        next.setOnClickListener(this);




         /*   @Override
            public void onClick(View view) {
                                            *//* FragmentTransaction fr = getFragmentManager().beginTransaction();
                                                 fr.replace(R.id.container,new Qualification()).addToBackStack(null).commit();}
*//*
                pager.setCurrentItem(1);
            }
        });*/

        String values[] = {"Gender", "Male", "Female", "Other"};

        Spinner spinner = (Spinner) v.findViewById(R.id.spinner);
        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner.setAdapter(adapter);



/*
        ((TextView)spinner.getSelectedView()).setError("Error message");
*/

       /* if (!values.equals(null))
        {
            int spinnerPostion = adapter.CharSequence(values);
            spinner.setSelection(spinnerPostion);
            spinnerPostion = 0;
        }
*/
        String[] values1 =
                {"Select Country", "Afghanistan", "Albania", "Algeria",
                        "Andorra", "Angola", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba",
                        "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium",
                        "Belize", "Benin",
                        "Bhutan", "Bolivia", "Bosnia and Herzegovina", "Botswana", "Brazil", "Brunei", "Bulgaria", "Burkina Faso", "Burma", "Burundi", "Cambodia", "Cameroon",
                        "Canada", "Cabo Verde",
                        "Central African Republic",
                        "Chad",
                        "Chile", "China", "Colombia", "Comoros", "Costa Rica", "Cote d'Ivoire", "Croatia", "Cuba", "Curacao", "Cyprus",
                        "Czechia",
                        "Denmark", "Djibouti", "Dominica", "Dominican Republic", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea",
                        "Estonia",
                        "Ethiopia", "Fiji", "Finland", "France", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Greece", "Grenada",
                        "Guatemala",
                        "Guinea",
                        "Guinea-Bissau", "Guyana", "Haiti", "Holy See", "Honduras", "Hong Kong", "Hungary", "Iceland", "India",
                        "Indonesia",
                        "Iran", "Iraq", "Ireland", "Israel", "Italy", "Jamaica",
                        "Japan",
                        "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea, North", "Korea, South", "Kosovo", "Kuwait", "Kyrgyzstan", "Laos", "Latvia", "Lebanon",
                        "Lesotho",
                        "Liberia", "Libya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau", "Macedonia", "Madagascar", "Malawi",
                        "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Mauritania", "Mauritius", "Mexico", "Micronesia", "Moldova", "Monaco",
                        "Mongolia",
                        "Montenegro", "Morocco", "Mozambique", "Namibia", "Nauru",
                        "Nepal",
                        "Netherlands", "New Zealand", "Nicaragua", "Niger", "Nigeria", "North Korea", "Norway", "Oman", "Pakistan", "Palau",
                        "Palestinian Territories", "Panama", "Papua New Guinea", "Paraguay",
                        "Peru",
                        "Philippines", "Poland", "Portugal", "Qatar", "Romania", "Russia", "Rwanda", "Saint Kitts and Nevis",
                        "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa",
                        "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Serbia", "Seychelles", "Sierra Leone", "Singapore", "Sint Maarten",
                        "Slovakia", "Slovenia", "Solomon Islands", "Somalia",
                        "South Africa", "South Korea", "South Sudan", "Spain",
                        "Sri Lanka", "Sudan", "Suriname", "Swaziland",
                        "Sweden", "Switzerland", "Syria", "Taiwan", "Tajikistan", "Tanzania", "Thailand", "Timor-Leste", "Togo", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "Uruguay", "Uzbekistan", "Vanuatu",
                        "Venezuela", "Vietnam", "Yemen", "Zambia", "Zimbabwe",
                };


        Spinner spinner1 = (Spinner) v.findViewById(R.id.spinner1);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values1);
        adapter1.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner1.setAdapter(adapter1);


        String values2[] = {"States", "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh", "Goa", "Gujarat", "Haryana",
                "Himachal Pradesh", "Jammu and Kashmir", "Jharkhand", "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya",
                "Mizoram", "Nagaland", "Odisha (Orissa)", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand"
                , "West Bengal"};

        Spinner spinner2 = (Spinner) v.findViewById(R.id.spinner2);
        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values2);
        adapter2.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner2.setAdapter(adapter2);

        String values3[] = {"City", "Abu", "Adoni", "Agra", "Agartala", "Almora", "Aligarh", "Alipore", "Alipur Duar", "Allahabad", "Amroha", "Ajmer", "Alwar", "Amer", "Ahmadabad", "Ahmadnagar", "Aizawl", "Akola", "Amravati", "Amritsar", "Aurangabad", "Alappuzha", "Ambala", "Amreli", "Amaravati", "Ambikapur", "Anantapur", "Anantnag", "Arunachal Pradesh", "Ara", "Arcot", "Asansol", "Assam", "Ayodhya", "Azamgarh",
                "Badagara", "Badami", "Balangir", "Baleshwar", "Ballari", "Bahraich", "Baharampur", "Bally", "Balurghat", "Bankura", "Baranagar", "Barasat", "Barrackpore", "Basirhat", "Bhatpara", "Bishnupur", "Budge Budge", "Burdwan", "Ballia", "Banda", "Bara Banki", "Bareilly", "Basti", "Bangalore", "Baruni", "Barmer", "Beawar", "Bharatpur", "Bhilwara", "Bijnor", "Bithur", "Bikaner", "Bundi", "Baramula", "Balaghat", "Barwani", "Baripada", "Batala", "Betul", "Begusarai", "Bettiah", "Bharuch", "Bhubaneshwar", "Bhandara", "Bhusawal", "Bid", "Buldana", "Belgavi", "Bhadravati", "Bharhut", "Brahmapur", "Bhind", "Bhojpur", "Bhopal", "Bidar", "Bhavnagar", "Bhuj", "Bhilai", "Bhiwani", "Bhagalpur", "Bihar Sharif", "Bilaspur", "Bodh Gaya", "Bokaro", "Burhanpur", "Buxar", "Budaun", "Bulandshahr",
                "Chandigarh", "Chandrapur", "Chandragiri", "Chamba", "Chapra", "Chandernagore", "Chengalpattu", "Chennai", "Chidambaram", "Chittoor", "Chaibasa", "Cherrapunji", "Chikkamagaluru", "Chitradurga", "Chhatarpur", "Chhindwara", "Chittaurgarh", "Churu", "Coimbatore", "Cuttack", "Cuddalore",
                "Daman", "Damoh", "Darbhanga", "Darjiling", "Datia", "Daulatabad", "Dewas", "Dalhousie", "Davangere", "Dehra Dun", "Dehri", "Delhi", "Deoghar", "Deoria", "Dhanbad", "Dhar", "Dharmshala", "Dhamtari", "Dhenkanal", "Dhaulpur", "Dharmapuri", "Dindigul", "Dungarpur", "Dhuburi", "Dhule", "Diu", "Dibrugarh", "Dispur", "Dinapur Nizamat", "Diamond Harbour", "Doda", "Dowlaiswaram", "Dum Dum", "Durgapur", "Durg", "Dwarka", "Deoghar", "Dumka",
                "Eluru", "Erode", "Etah", "Etawah", "Eluru", "Erode",

                "Faridabad", "Faizabad", "Farrukhabad-cum-Fatehgarh", "Fatehpur", "Fatehpur Sikri", "Firozpur Jhirka", "Faridkot", "Firozpur",
                "Gandhinagar", "Ganganagar", "Gangtok", "Gaya", "Ghaziabad", "Ghazipur", "Giridih", "Gulmarg", "Guntur", "Gurgaon", "Gurdaspur", "Guwahati", "Guna", "Gwalior", "Godhra", "Gonda", "Gorakhpur", "Gyalsing",
                "Hajipur", "Halebid", "Hamirpur", "Hamirpur", "Halisahar", "Haora", "Hardoi", "Hathras", "Hanumangarh", "Hansi", "Hassan", "Hazaribag", "Haridwar", "Hisar", "Hoshangabad", "Hoshiarpur", "Hubballi-Dharwad", "Hugli", "Hyderabad",
                "Idukki", "Imphal", "Ingraj Bazar", "Indore", "Itarsi", "Itanagar",
                "Jagdalpur", "Jaipur", "Jaisalmer", "Jalpaiguri", "Jalor", "Jalaun", "Jaunpur", "Jhansi", "Jhalawar", "Jhunjhunu", "Jodhpur", "Jalandhar", "Jamalpur", "Jamnagar", "Jammu", "Jabalpur", "Jalgaon", "Jamshedpur", "Jharia", "Jhabua", "Jind", "Junagadh", "Jorhat",
                "Kadapa", "Kakinada", "Kapurthala", "Karimnagar", "Kannauj", "Kanpur", "Khammam", "Kishangarh", "Kurnool", "Kota", "Koch Bihar", "Kolkata", "Krishnanagar",
                "Lachung", "Leh", "Lunglei", "Ludhiana",
                "Kaithal", "Kalimpong", "Kamarhati", "Kanchrapara", "Kharagpur", "Kangra", "Karnal", "Kalyan", "Kandla", "Karli", "Karaikal", "Kalaburagi", "Kannur", "Katihar", "Kathua", "Kanchipuram", "Kanniyakumari", "Keonjhar", "Khajuraho", "Khandwa", "Khargon", "Khambhat", "Kheda", "Kochi", "Kohima", "Kodaikanal", "Kolhapur", "Konark", "Koraput", "Kollam", "Kottayam", "Kozhikode", "Kolar", "Kumbakonam", "Kurukshetra", "Kullu",
                "Lakhimpur", "Lalitpur", "Lucknow",
                "Madhubani", "Madgaon", "Machilipatnam", "Madikeri", "Madurai", "Mahbubnagar", "Malda", "Mamallapuram", "Mandi", "Mattancheri", "Mahe", "Mangan", "Mahesana", "Maheshwar", "Mahabaleshwar", "Malegaon", "Mainpuri", "Mathura", "Meerut", "Merta", "Matheran", "Midnapore", "Mumbai", "Mandla", "Mandsaur", "Mandya", "Mangaluru", "Mirzapur-Vindhyachal", "Moradabad", "Muzaffarnagar", "Mhow", "Mon", "Motihari", "Munger", "Muzaffarpur", "Morvi", "Morena", "Murwara", "Mysuru", "Murshidabad", "Mussoorie",
                "Nabha", "Nadiad", "Nagaon", "Nagpur", "Nagaur", "Nagappattinam", "Nagercoil", "Nathdwara", "Nagarjunakoṇḍa", "Nahan", "Nanded", "Nainital", "Nashik", "Narsimhapur", "Narsinghgarh", "Narwar", "Navadwip", "New Delhi", "Neemuch", "Navsari", "Nizamabad", "Nowgong",
                "Okha", "Orchha", "Osmanabad",
                "Pali", "Panipat", "Panaji", "Patna", "Patiala", "Palakkad", "Palanpur", "Palayankottai", "Palashi", "Panihati", "Panna", "Pandharpur", "Parbhani", "Paradip", "Patan", "Partapgarh", "Pehowa", "Pithoragarh", "Pilibhit", "Porbandar", "Phalodi", "Pushkar", "Phulabani", "Phek", "Puri", "Punch", "Pune", "Pudukkottai", "Purnia", "Purulia", "Pusa",
                "Rae Bareli", "Raiganj", "Rajahmundry", "Rajmahal", "Rajauri", "Rajapalaiyam", "Rampur", "Ramanathapuram", "Ranchi", "Raichur", "Raipur", "Raisen", "Rajnandgaon", "Rajgarh", "Ratlam", "Ratnagiri", "Rajkot", "Rewa", "Rewari", "Rohtak", "Rupnagar",
                "Sagar", "Santipur", "Sarangpur", "Satna", "Saharsa", "Samastipur", "Saharanpur", "Shahjahanpur", "Sambhal", "Sangareddi", "Saraikela", "Sasaram", "Sehore", "Seoni", "Shahdol", "Shimla", "Shajapur", "Sirsa", "Sitamarhi", "Silvassa", "Siwan", "Surat", "Surendranagar", "Sonipat", "Srinagar",
                "Sangli", "Salem", "Satara", "Sambalpur", "Sangrur", "Sevagram", "Sawai Madhopur", "Shahpura", "Shantiniketan", "Shrirampur", "Siliguri", "Siuri", "Sikar", "Sirohi", "Sibsagar", "Silchar", "Sitapur", "Sheopur", "Shillong", "Shivpuri", "Shivamogga", "Shravanabelagola", "Shrirangapattana", "Solapur", "Srikakulam", "Sultanpur",
                "Tamluk", "Tezpur", "Tinsukia", "Tirupati", "Tumkuru", "Thalassery", "Thane", "Thanjavur", "Tehri", "Titagarh", "Tiruchchirappalli", "Tirunelveli", "Tiruppur", "Tuticorin", "Thiruvananthapuram", "Thrissur", "Tonk"
                , "Udhampur", "Udhagamandalam", "Udayagiri", "Udaipur", "Ujjain", "Una", "Ulhasnagar",
                "Valsad", "Varanasi", "Veraval", "Vidisha", "Vijayawada", "Visakhapatnam", "Vizianagaram", "Vasai-Virar", "Vellore",
                "Yanam", "Yavatmal", "Yemmiganur",
                "Wardha", "Warangal", "Wokha"
                , "Zunheboto",


        };


        Spinner spinner3 = (Spinner) v.findViewById(R.id.spinner3);
        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values3);
        adapter3.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner3.setAdapter(adapter3);

        return v;

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        // On selecting a spinner item
        String item = parent.getItemAtPosition(position).toString();

        // Showing selected spinner item
        Toast.makeText(parent.getContext(), "Selected: " + item, Toast.LENGTH_LONG).show();

    }

    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void onClick(View view) {
        if (view == next) ;
        usernext();
    }

    private void usernext() {

        String Name = editTextName.getText().toString().trim().toLowerCase();
        String LName = editTextLName.getText().toString().trim().toLowerCase();
        String spinner = spinnerText.getSelectedItem().toString().trim().toLowerCase();
        String phone = Phone.getText().toString().trim().toLowerCase();
        String email = Email.getText().toString().trim().toLowerCase();
        String password = Password.getText().toString().trim();
        String cpassword = Cpassword.getText().toString().trim();
        String DOB = dob.getText().toString().trim().toLowerCase();
        String adhar = Adhar.getText().toString().trim().toLowerCase();
        String spinner1 = Spinner1.getSelectedItem().toString().trim().toLowerCase();
        String spinner2 = Spinner2.getSelectedItem().toString().trim().toLowerCase();
        String spinner3 = Spinner3.getSelectedItem().toString().trim().toLowerCase();
        String zip = Zip.getText().toString().trim().toLowerCase();
        awesomeValidation = new AwesomeValidation(COLORATION);
        awesomeValidation.addValidation(getActivity(), R.id.Name, "[a-zA-Z\\s]+", R.string.err_name);
        awesomeValidation.addValidation(getActivity(), R.id.LName, "[a-zA-Z\\s]+", R.string.err_lname);
/*
        awesomeValidation.addValidation(getActivity(), R.id.spinner, "[a-zA-Z\\s]+", R.string.err_spinner);
*/

        awesomeValidation.addValidation(getActivity(), R.id.phone, "\\d{10}", R.string.err_phone);
        awesomeValidation.addValidation(getActivity(), R.id.email, Patterns.EMAIL_ADDRESS, R.string.err_email);
        awesomeValidation.addValidation(getActivity(), R.id.password, "[a-zA-Z0-9\\!\\@\\#\\$]{8,24}", R.string.err_pass);
        awesomeValidation.addValidation(getActivity(), R.id.cpassword, String.valueOf(R.id.password), R.string.err_cpass);

     /*   if ((Cpassword.getText().toString().trim()).equals((Password.getText().toString().trim()) )) {
            awesomeValidation.addValidation(getActivity(), R.id.cpassword, "", R.string.err_cpass);
        }*/
       /* else{
            Toast.makeText(getActivity().this, "else", Toast.LENGTH_LONG).show();
        }*/

/*
        awesomeValidation.addValidation(getActivity(), R.id.DOB, "(0?[1-9]|1[012]) [/.-] (0?[1-9]|[12][0-9]|3[01]) [/.-] ((19|20)\\d\\d)", R.string.err_dob);
*/
        awesomeValidation.addValidation(getActivity(), R.id.adhar, "\\d+", R.string.err_aadhar);
        awesomeValidation.addValidation(getActivity(), R.id.zip, "\\d+", R.string.err_zip);

        awesomeValidation.addValidation(getActivity(), R.id.DOB, "\\d{2}[/.-]\\d{2}[/.-]\\d{4}", R.string.err_dob);
        awesomeValidation.validate();

                /*String.valueOf(new SimpleCustomValidation() {
              @Override
              public boolean compare(String input) {
                  // check if the age is >= 18
                  try {
                      Calendar calendarBirthday = Calendar.getInstance();
                      Calendar calendarToday = Calendar.getInstance();
                      calendarBirthday.setTime(new SimpleDateFormat("dd/MM/yyyy", Locale.US).parse(input));
                      int yearOfToday = calendarToday.get(Calendar.YEAR);
                      int yearOfBirthday = calendarBirthday.get(Calendar.YEAR);
                      if (yearOfToday - yearOfBirthday > 18) {
                          return true;
                      } else if (yearOfToday - yearOfBirthday == 18) {
                          int monthOfToday = calendarToday.get(Calendar.MONTH);
                          int monthOfBirthday = calendarBirthday.get(Calendar.MONTH);
                          if (monthOfToday > monthOfBirthday) {
                              return true;
                          } else if (monthOfToday == monthOfBirthday) {
                              if (calendarToday.get(Calendar.DAY_OF_MONTH) >= calendarBirthday.get(Calendar.DAY_OF_MONTH)) {
                                  return true;
                              }
                          }
                      }
                  } catch (ParseException e) {
                      e.printStackTrace();
                  }
                  return false;
              }
          }), R.string.err_dob);
*/





        /*   String dpStart = datePicker.getYear() + "-" + datePicker.getMonth() + 1 + "-" + datePicker.getDayOfMonth();



*/

        nextclick(Name, LName, spinner, phone, email, password, cpassword, DOB, adhar, spinner1, spinner2, spinner3, zip);
    }

    private void nextclick(final String name, final String LName, final String spinner, final String phone, final String email, final String password, final String cpassword, final String DOB, final String adhar, final String spinner1, final String spinner2, final String spinner3, final String zip) {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, REGISTER_URL,
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(getActivity(), response, Toast.LENGTH_LONG).show();

                    }
                },
                new com.android.volley.Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), error.toString(), Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<String, String>();
                map.put("name", name);
                map.put("Last name", LName);
                map.put("spinner", spinner);
                map.put("phone", phone);
                map.put("Email", email);
                map.put("password", password);
                map.put("confirm password", cpassword);
                map.put("DOB", DOB);
                map.put("Adhar number", adhar);
                map.put("country", spinner1);
                map.put("state", spinner2);
                map.put("city", spinner3);
                map.put("ZIP", zip);
                return map;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(getActivity().getApplicationContext());
        requestQueue.add(stringRequest);
    }

}
/*

    private boolean checkValidation() {
        if (spinner.getSelectedItem().toString().equals("")) {
            ArrayAdapter adapter = (ArrayAdapter) spinner.getAdapter();
            View view = spinner.getSelectedView();
            adapter.setError(view, "Please select a value");

            return false;
*/



    /*public void setError(String errorMessage) {
        if (null != mEmptyText) {
            mEmptyText.setError(errorMessage);
        } else {
            Log.d(TAG, "mEmptyText is null");

        }
    }
}*/





    /*
    private void initValidation(String style) {
        switch (ValidationStyle.valueOf(style)) {
            case BASIC:
                mAwesomeValidation = new AwesomeValidation(BASIC);
                break;
            case COLORATION:
                mAwesomeValidation = new AwesomeValidation(COLORATION);
                mAwesomeValidation.setColor(Color.YELLOW);
                break;
            case UNDERLABEL:
                mAwesomeValidation = new AwesomeValidation(UNDERLABEL);
                mAwesomeValidation.setContext(getActivity());
                break;

            case TEXT_INPUT_LAYOUT:
                mAwesomeValidation = new AwesomeValidation(TEXT_INPUT_LAYOUT);
                mAwesomeValidation.setTextInputLayoutErrorTextAppearance(R.style.TextInputLayoutErrorStyle);
                break;

        }
    }*/

    /*private void addValidationForEditText(Activity activity) {
        mAwesomeValidation.addValidation(activity, R.id.edt_name, "[a-zA-Z0-9_-]+", R.string.err_name);

    }*/
