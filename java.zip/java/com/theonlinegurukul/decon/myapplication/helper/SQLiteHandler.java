/**
 * Author: Ravi Tamada
 * URL: www.androidhive.info
 * twitter: http://twitter.com/ravitamada
 * */
package com.theonlinegurukul.decon.myapplication.helper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.HashMap;

public class SQLiteHandler extends SQLiteOpenHelper {

	private static final String TAG = SQLiteHandler.class.getSimpleName();
	private Cursor cursor;
	private SQLiteDatabase dataBase = null;
	private ContentValues cValues;
	// All Static variables// Database Version
	public static final int DATABASE_VERSION = 1;
	// Database Name
	public static final String DATABASE_NAME = "tog.sqlite";
	//Table name
	/////////////////////////////////////////////////
	public static final String TABLE_USER_MASTER = "usermaster";
	public static final String TABLE_TEACHER_BASIC = "teacherbasic";
	public static final String TABLE_TEACHER_QUALIFICATON= "teacherqualification";
	public static final String TABLE_TEACHER_CLASS = "teacherclass";
	public static final String TABLE_TEACHER_BANK_DETAILS = "teacherbankdetails";
	public static final String TABLE_TEACHER_INFO = "teacherinfo";

	//student dashboard tAables
	public static final String TABLE_TEACHER_DASHBOARD = "teacher_dashboard";

	public static final String TABLE_CATEGORY = "category";
	public static final String TABLE_CLASS = "class";
	public static final String TABLE_SUBJECT = "subject";

	//COURSES TABLE
	public static final String TABLE_V2_COURSE_NEW = "v2_course_new";
	public static final String TABLE_V2_COURSE_CLASS_DETAILS= "v2_course_class_details";


	public static final String KEY_ID = "id";
	public static final String KEY_FIRST_NAME = "name";
	public static final String KEY_lAST_NAME = "lname";
	public static final String KEY_MOBILE = "mobile";
	public static final String KEY_EMAIL = "email";
	public static final String KEY_PASSWORD = "password";
	public static final String KEY_GENDER = "gender";



	public static final String KEY_DOB = "dob";
	public static final String KEY_COUNTRY = "country";
	public static final String KEY_STATE = "state";
	public static final String KEY_CITY = "city";
	public static final String KEY_ZIP_CODE = "zip_code";
	public static final String KEY_AADHAR = "aadhar";
	public static final String KEY_PAN_CARD = "pan_card";
	public static final String KEY_QUALIFICATION = "qualification";
	public static final String KEY_UNIVERSITY = "university";
	public static final String KEY_PASSING_YEAR = "passingyear";
	public static final String KEY_GRADE = "grade";
	public static final String KEY_CLASS = "class";
	public static final String KEY_PRIMARY_SUBJECT = "psubject";
	public static final String KEY_SECONDARY_SUBJECT = "ssubject";
	public static final String KEY_OTHERS = "others";
	public static final String KEY_BANK_NAME = "bank";
	public static final String KEY_BRANCH_NAME = "branch";
	public static final String KEY_ACCOUNT_HOLDER = "account";
	public static final String KEY_ACCOUNT_NUMBER = "accountnumber";
	public static final String KEY_IFSC = "ifsc";
	public static final String KEY_MICR = "micr";
	public static final String KEY_CURRENT_OCCUPTION = "currentoccuption";
	public static final String KEY_DAYS_AVAILABLE = "daysavailable";
	public static final String KEY_DAILY_HOURS = "dayshours";
	public static final String KEY_TEACHING_TIME = "teachingtime";
	public static final String KEY_EXPERINCE = "experience";
	public static final String KEY_CONNECTION_TYPE = "connectiontype";
	public static final String KEY_INTERNET_SPEED = "internet";
	public static final String KEY_UPLOAD_SPEED = "upload";
	public static final String KEY_SCREEN_SHOT = "screenshot";
	public static final String KEY_PROFILE_PIC = "profile";
	public static final String KEY_CV = "cv";
	public static final String KEY_ASSOCIATE_GURUKUL = "associate";
	public static final String ABOUT_GURUKUL = "about";
	public static final String GOOGLE_ID = "gooleid";
	public static final String FB_ID = "fb";

	public static final String USER_ID = "userid";

	public static final String UID = "uid";

//TEACHER DASHBOARD
	public static final String CATEGORY = "category";
	public static final String CLASS = "class";
	public static final String SUBJECT = "subject";
	public static final String SUBJECT_CODE = "subject_code";

	public static final String CLASS_ID = "class_id";
	public static final String CLASS_DATE = "class_date";
	public static final String COURSE_START_DATE = "course_start_date";
	public static final String COURSE_END_DATE = "course_end_date";
	public static final String CLASS_START_TIME = "class_start_time";
	public static final String CLASS_END_TIME = "class_end_time";
	public static final String CLASS_DURATION_MIN = "class_duration_min";
	public static final String CLASS_EXTENDED_TIME_MIN = "class_extended_time_min";
	public static final String FACULTY_CODE = "faculty_code";
	public static final String TIME_ZONE = "time_zone";

	public static final String COURSE_ID = "course_id";
	public static final String TOTAL_EARN = "total_earn";




	public static final String CATEGORY_ID = "category_id";
	public static final String DESCRIPTION = "description";
	public static final String CATEGORY_CODE = "categorycode";
	public static final String STATUS = "status";
	public static final String CREATED_AT = "create_at";
	public static final String UPDATE_AT = "update_at";
	public static final String CREATE_BY = "create_by";
	public static final String UPDATE_BY = "update_by";
	public static final String COURSE_ID_TAG = "course_id_tag";




	public static final String CLASS_CODE = "class_code";



	public static final String PER_CLASS_AMOUNT = "update_by";
	public static final String CLASS_COUNT = "update_by";
	public static final String COURSE_CUSTOM_DATE = "update_by";
	public static final String COURSE_WEEK_DAYS = "update_by";
	public static final String COURSE_DURATION = "update_by";
	public static final String COURSE_FURTHER_EXTENDED = "update_by";
	public static final String SUBJECT_ID= "update_by";


	public static final String CLASS_TAG_ID = "update_by";
	public static final String CLASS_STRENGTH = "update_by";
	public static final String METHOD_INFO = "update_by";
	public static final String METHOD ="";
	public static final String PART_OF_COURSE_EXTENDED="";
	public static final String RECORDING_URL = "";


	public SQLiteHandler(Context context) {
		super(context, context.getExternalFilesDir(null).getAbsolutePath()
				+ "/" + DATABASE_NAME, null, DATABASE_VERSION);
	}

	@Override
		public void onCreate(SQLiteDatabase db) {
//Teacher registration
		String CREATE_USER_MASTER = "CREATE TABLE " + TABLE_USER_MASTER + "("
				+ KEY_ID + " INTEGER PRIMARY KEY," + KEY_FIRST_NAME + " TEXT," + KEY_lAST_NAME + " TEXT,"
				+ KEY_MOBILE + " TEXT," + KEY_EMAIL + "TEXT ," + KEY_PASSWORD + " TEXT,"
				+ KEY_GENDER + " TEXT,"
				+ KEY_PROFILE_PIC + " TEXT," + GOOGLE_ID + " TEXT," + FB_ID + "TEXT " + ")";
		db.execSQL(CREATE_USER_MASTER);



		String CREATE_TEACHER_BASIC = "CREATE TABLE " + TABLE_TEACHER_BASIC + "("+USER_ID + " INTEGER PRIMARY KEY ,"+
				KEY_DOB +" TEXT" + KEY_COUNTRY + " TEXT ,"+ KEY_STATE + " TEXT ,"+ KEY_CITY + " TEXT," + KEY_ZIP_CODE + " TEXT"+
				KEY_AADHAR + " TEXT" +KEY_PAN_CARD+" TEXT" + KEY_SCREEN_SHOT+ " TEXT"   + KEY_CV+ " TEXT, "+")";
		db.execSQL(CREATE_TEACHER_BASIC);

		String CREATE_TEACHER_QUALIFICATON = "CREATE TABLE " + TABLE_TEACHER_QUALIFICATON + "("
				+KEY_QUALIFICATION+ " TEXT" + KEY_UNIVERSITY+ " TEXT" + KEY_PASSING_YEAR+ " TEXT"+ KEY_GRADE+ " TEXT ,"+")";
		db.execSQL(CREATE_TEACHER_QUALIFICATON);

		String CREATE_TEACHER_BANK_DETAILS = "CREATE TABLE " + TABLE_TEACHER_BANK_DETAILS + "("+ KEY_BANK_NAME+ " TEXT" +
		KEY_BRANCH_NAME + " TEXT" + KEY_ACCOUNT_HOLDER+ " TEXT" + KEY_ACCOUNT_NUMBER + " TEXT" + KEY_IFSC+ " TEXT" + KEY_MICR+ " TEXT" +")";
		db.execSQL(CREATE_TEACHER_BANK_DETAILS);

		String CREATE_TEACHER_CLASS = "CREATE TABLE " + TABLE_TEACHER_CLASS + "("+
				KEY_CLASS+ " TEXT"+
				KEY_PRIMARY_SUBJECT+ " TEXT" + KEY_SECONDARY_SUBJECT + " TEXT" + KEY_OTHERS+ " TEXT "+")";
		db.execSQL(CREATE_TEACHER_CLASS);

		String CREATE_TEACHER_INFO = "CREATE TABLE " + TABLE_TEACHER_INFO + "("+
				KEY_CURRENT_OCCUPTION+ " TEXT" + KEY_DAYS_AVAILABLE+ " TEXT" + KEY_DAILY_HOURS+ " TEXT" + KEY_TEACHING_TIME+ " TEXT"+
				KEY_EXPERINCE+ " TEXT" + KEY_CONNECTION_TYPE+ " TEXT" + KEY_INTERNET_SPEED + " TEXT" + 	KEY_UPLOAD_SPEED+ " TEXT" +
				 	KEY_ASSOCIATE_GURUKUL+ " TEXT" +
				ABOUT_GURUKUL+ " TEXT ,"+")";
		db.execSQL(CREATE_TEACHER_INFO);



		String CREATE_TEACHER_DASHBOARD = "CREATE TABLE " + TABLE_TEACHER_DASHBOARD + "("+
				CATEGORY+ " TEXT" +CLASS+ " TEXT" + SUBJECT+ " TEXT" + SUBJECT_CODE+ "TEXT" +
				CLASS_ID + " TEXT" + CLASS_DATE + " TEXT" + COURSE_START_DATE + " TEXT" + COURSE_END_DATE + " TEXT" + CLASS_START_TIME+
				" TEXT"+ CLASS_END_TIME + "TEXT" + CLASS_DURATION_MIN + "TEXT" + CLASS_EXTENDED_TIME_MIN + "TEXT" +
				FACULTY_CODE + "TEXT" +COURSE_ID+ "TEXT" + TIME_ZONE + "TEXT"+
				TOTAL_EARN + "TEXT"+")";
		db.execSQL(CREATE_TEACHER_DASHBOARD);
		Log.d(TAG, "Database tables created");







		//create table teacherdashboard
/*
		String CREATE_CATEGORY = "CREATE TABLE " + TABLE_CATEGORY + "("+
				UID+ " TEXT" + CATEGORY+ " TEXT" + DESCRIPTION+ " TEXT" + CATEGORY_CODE+ " TEXT"+
				STATUS+ " TEXT" + CREATED_AT+ " TEXT" + UPDATE_AT + " TEXT" + 	CREATE_BY+ " TEXT" +
				UPDATE_BY+ " TEXT ,"+")";
		db.execSQL(CREATE_CATEGORY);

		String CREATE_CLASS = "CREATE TABLE " + TABLE_CLASS + "("+
				UID+ " TEXT" + CLASS+ " TEXT" + DESCRIPTION+ " TEXT" + CATEGORY_ID+ " TEXT"+ CLASS_CODE + "TEXT" +
				STATUS+ " TEXT" + CREATED_AT+ " TEXT" + UPDATE_AT + " TEXT" + 	CREATE_BY+ " TEXT" +
				UPDATE_BY+ " TEXT ,"+")";
		db.execSQL(CREATE_CLASS);


		String CREATE_SUBJECT = "CREATE TABLE " + TABLE_SUBJECT + "("+
				UID+ " TEXT" + SUBJECT+ " TEXT" + DESCRIPTION+ " TEXT" + CLASS_ID+ " TEXT"+ CATEGORY_ID + "TEXT" +
				SUBJECT_CODE + "TEXT" + STATUS+ " TEXT" + CREATED_AT+ " TEXT" + UPDATE_AT + " TEXT" + 	CREATE_BY+ " TEXT" +
				UPDATE_BY+ " TEXT ,"+")";
		db.execSQL(CREATE_SUBJECT);
		Log.d(TAG, "Database tables created");

		//	Log.i("testdb", "Database tables created");
		//}

		String CREATE_V2_COURSE_NEW = "CREATE TABLE " + TABLE_V2_COURSE_NEW + "("+
			COURSE_ID_TAG+ " TEXT" + COURSE_START_DATE + " TEXT" + COURSE_END_DATE + " TEXT" + CLASS_START_TIME+
				" TEXT"+ CLASS_END_TIME + "TEXT" + CLASS_DURATION_MIN + "TEXT" + CLASS_EXTEND_TIME_MIN + "TEXT" +PER_CLASS_AMOUNT + "TEXT"+
		       CLASS_COUNT + "TEXT" + CATEGORY_ID + "TEXT" + CLASS_ID + "TEXT" +SUBJECT_ID + "TEXT" + FACULTY_CODE + "TEXT" +
				COURSE_CUSTOM_DATE + "TEXT" + COURSE_WEEK_DAYS + "TEXT" + TIME_ZONE + "TEXT"+
				SUBJECT_CODE + "TEXT" + COURSE_DURATION + " TEXT" + COURSE_FURTHER_EXTENDED + " TEXT,"+")";
		db.execSQL(CREATE_V2_COURSE_NEW);
		Log.d(TAG, "Database tables created");

	//	Log.i("testdb", "Database tables created");
	//}

		String CREATE_V2_COURSE_CLASS_DETAILS = "CREATE TABLE " + TABLE_V2_COURSE_CLASS_DETAILS + "("+
			COURSE_ID+ " TEXT" +CLASS_TAG_ID+ " TEXT" + CLASS_STRENGTH+ " TEXT" + CLASS_DATE+ "TEXT" +
			COURSE_START_DATE + " TEXT" + COURSE_END_DATE + " TEXT" + CLASS_START_TIME+
			" TEXT"+ CLASS_END_TIME + "TEXT" + CLASS_DURATION_MIN + "TEXT" + CLASS_EXTEND_TIME_MIN + "TEXT" +
			CLASS_COUNT + "TEXT" + CATEGORY_ID + "TEXT" + CLASS_ID + "TEXT" +SUBJECT_ID + "TEXT" + METHOD + "TEXT" +
			METHOD_INFO + "TEXT" + PART_OF_COURSE_EXTENDED + "TEXT" + TIME_ZONE + "TEXT"+
			SUBJECT_CODE + "TEXT" + RECORDING_URL + " TEXT,"+")";
		db.execSQL(CREATE_V2_COURSE_CLASS_DETAILS);
		Log.d(TAG, "Database tables created");
*/












		//	Log.i("testdb", "Database tables created");
	//}
}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// Drop older table if existed

		db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER_MASTER);
		db.execSQL("DROP TABLE IF EXISTS " + TABLE_CATEGORY);
		db.execSQL("DROP TABLE IF EXISTS " + TABLE_TEACHER_DASHBOARD);
		onCreate(db);
		// Create tables again
		// onCreate(db);
	}

	public void addusermaster(String name, String lname, String moblie, String email, String password,
						    String gender) {
		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(KEY_FIRST_NAME, name);
		values.put(KEY_lAST_NAME, lname);
		values.put(KEY_MOBILE, moblie);
		values.put(KEY_EMAIL, email);
		values.put(KEY_PASSWORD, password);
		values.put(KEY_GENDER, gender);
		/*values.put(KEY_ZIP, zip);*/

		long id = db.insert(TABLE_USER_MASTER, null, values);
		db.close(); // Closing database connection
		Log.d(TAG, "New user inserted into sqlite: " + id);
	}

	public void addcategoty(String uid, String category, String description, String categoty_code, String status,
							  String created_at,String update_by,String create_by,String update_at) {
		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(UID, uid);
		values.put(CATEGORY, category);
		values.put(DESCRIPTION, description);
		values.put(CATEGORY_CODE, categoty_code);
		values.put(STATUS, status);
		values.put(CREATED_AT, created_at);
		values.put(UPDATE_BY, update_by);
		values.put(CREATE_BY, create_by);
		values.put(UPDATE_AT, update_at);


		long id = db.insert(TABLE_CATEGORY, null, values);
		db.close(); // Closing database connection
		Log.d(TAG, "New user inserted into sqlite: " + id);
	}
	public void addTeacherdashboard(String category,String clas,String subject,String subject_code,String class_id,String class_date,
									String course_start_date,String course_end_date,String class_start_time, String class_end_time,
									String class_duration_min,String class_extended_time_min,String faculty_code,String course_id,
									String time_zone,String total_earn) {
		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(CATEGORY, category); // Name
		values.put(CLASS, clas); // Email
		values.put(SUBJECT, subject); // Email
		values.put(SUBJECT_CODE, subject_code); // Email
		values.put(CLASS_ID, class_id); // Email
		values.put(CLASS_DATE, class_date); // Email
		values.put(COURSE_START_DATE, course_start_date); // Email
		values.put(COURSE_END_DATE, course_end_date); // Email
		values.put(CLASS_START_TIME, class_start_time); // Created At
		values.put(CLASS_END_TIME, class_end_time); // Created At
		values.put(CLASS_DURATION_MIN, class_duration_min); // Created At
		values.put(CLASS_EXTENDED_TIME_MIN, class_extended_time_min); // Created At
		values.put(FACULTY_CODE, faculty_code); // Created At
		values.put(COURSE_ID, course_id); // Created At
		values.put(TIME_ZONE, time_zone); // Created At
		values.put(TOTAL_EARN, total_earn); // Created At

		long id = db.insert(TABLE_TEACHER_DASHBOARD, null, values);
		db.close(); // Closing database connection
		Log.d(TAG, "New user inserted into sqlite: " + id);
	}
	public Cursor getListContents() {
		SQLiteDatabase db = this.getWritableDatabase();
		Cursor data = db.rawQuery("SELECT * FROM " + TABLE_TEACHER_DASHBOARD, null);
		return data;
	}











	/*public void deleteUsermaster() {
		SQLiteDatabase db = this.getWritableDatabase();
		// Delete All Rows
		db.delete(TABLE_USER_MASTER, null, null);
		db.close();
		Log.d(TAG, "Deleted all user info from sqlite");
	}*/

}


















