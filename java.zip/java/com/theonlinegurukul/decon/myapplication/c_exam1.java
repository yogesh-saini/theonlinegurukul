package com.theonlinegurukul.decon.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class c_exam1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c_exam1);
    }
}
