package com.theonlinegurukul.decon.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import com.theonlinegurukul.decon.myapplication.teacherdashboard.Alloted_courses;
import com.theonlinegurukul.decon.myapplication.teacherdashboard.Approved_class;
import com.theonlinegurukul.decon.myapplication.teacherdashboard.Earning;
import com.theonlinegurukul.decon.myapplication.teacherdashboard.Recent_class;

public class Student_dashboard extends AppCompatActivity implements View.OnClickListener {
    private CardView detail, allot,recents,earnings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Student_Dashboard");
        setContentView(R.layout.activity_student_dashboard);

        detail = (CardView) findViewById(R.id.details);
        allot = (CardView) findViewById(R.id.alloted);
        recents = (CardView) findViewById(R.id.recent);
        earnings = (CardView) findViewById(R.id.earning);

        detail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Student_dashboard.this, Approved_class.class);
                startActivity(i);
            }
        });
        allot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Student_dashboard.this, Alloted_courses.class);
                startActivity(i);
            }
        });
        recents.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Student_dashboard.this, Recent_class.class);
                startActivity(i);
            }
        });

        earnings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Student_dashboard.this, Earning.class);
                startActivity(i);
            }
        });

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.example_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu:
                Intent intent = new Intent(Student_dashboard.this, Upload_Avatar.class);
//           Toast.makeText(this, "item1 select", Toast.LENGTH_SHORT);
                startActivity(intent);
        }
        switch (item.getItemId()) {
            case R.id.menu1:
                Intent intent = new Intent(Student_dashboard.this, Edit_profile.class);
                startActivity(intent);

        }
        switch (item.getItemId()) {
            case R.id.menu2:
                Intent intent = new Intent(Student_dashboard.this, View_profile.class);
                startActivity(intent);

        }
        switch (item.getItemId()) {
            case R.id.menu3:
                /*Fragment fragment = new stud1();
                getSupportFragmentManager().beginTransaction().replace(R.id.frame,fragment).commit();
                *//*FragmentTransaction fr = getFragmentManager().beginTransaction();
                fr.replace(R.id.frame,new stud1()).addToBackStack(null).commit();*/

                Intent intent = new Intent(Student_dashboard.this, MainActivity.class);
                startActivity(intent);
        }


        return super.onOptionsItemSelected(item);


    }

    @Override
    public void onClick(View view) {

    }

/*
    @Override
    public void onClick(View view) {
        */
/*Intent i;*//*

        */
/* Toast.makeText(this, "send", Toast.LENGTH_SHORT).show();
*//*

    }

    @Override
    public void onClick(View v) {
*/
//        }
}


