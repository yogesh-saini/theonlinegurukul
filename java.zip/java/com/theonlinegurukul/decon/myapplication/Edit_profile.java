package com.theonlinegurukul.decon.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class Edit_profile extends AppCompatActivity {


    String[] values =
            {"Select Country","Afghanistan", "Albania", "Algeria",
                    "Andorra", "Angola", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba",
                    "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium",
                    "Belize", "Benin",
                    "Bhutan", "Bolivia", "Bosnia and Herzegovina", "Botswana", "Brazil", "Brunei", "Bulgaria", "Burkina Faso", "Burma", "Burundi", "Cambodia", "Cameroon",
                    "Canada", "Cabo Verde",
                    "Central African Republic",
                    "Chad",
                    "Chile", "China", "Colombia", "Comoros", "Costa Rica", "Cote d'Ivoire", "Croatia", "Cuba", "Curacao", "Cyprus",
                    "Czechia",
                    "Denmark", "Djibouti", "Dominica", "Dominican Republic", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea",
                    "Estonia",
                    "Ethiopia", "Fiji", "Finland", "France", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Greece", "Grenada",
                    "Guatemala",
                    "Guinea",
                    "Guinea-Bissau", "Guyana", "Haiti", "Holy See", "Honduras", "Hong Kong", "Hungary", "Iceland", "India",
                    "Indonesia",
                    "Iran", "Iraq", "Ireland", "Israel", "Italy", "Jamaica",
                    "Japan",
                    "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea, North", "Korea, South", "Kosovo", "Kuwait", "Kyrgyzstan", "Laos", "Latvia", "Lebanon",
                    "Lesotho",
                    "Liberia", "Libya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau", "Macedonia", "Madagascar", "Malawi",
                    "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Mauritania", "Mauritius", "Mexico", "Micronesia", "Moldova", "Monaco",
                    "Mongolia",
                    "Montenegro", "Morocco", "Mozambique", "Namibia", "Nauru",
                    "Nepal",
                    "Netherlands", "New Zealand", "Nicaragua", "Niger", "Nigeria", "North Korea", "Norway", "Oman", "Pakistan", "Palau",
                    "Palestinian Territories", "Panama", "Papua New Guinea", "Paraguay",
                    "Peru",
                    "Philippines", "Poland", "Portugal", "Qatar", "Romania", "Russia", "Rwanda", "Saint Kitts and Nevis",
                    "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa",
                    "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Serbia", "Seychelles", "Sierra Leone", "Singapore", "Sint Maarten",
                    "Slovakia", "Slovenia", "Solomon Islands", "Somalia",
                    "South Africa", "South Korea", "South Sudan", "Spain",
                    "Sri Lanka", "Sudan", "Suriname", "Swaziland",
                    "Sweden", "Switzerland", "Syria", "Taiwan", "Tajikistan", "Tanzania", "Thailand", "Timor-Leste", "Togo", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "Uruguay", "Uzbekistan", "Vanuatu",
                    "Venezuela", "Vietnam", "Yemen", "Zambia", "Zimbabwe",
            };



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, values);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner.setAdapter(adapter);



    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.example_menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu:
                Intent intent = new Intent(Edit_profile.this, Upload_Avatar.class);
//           Toast.makeText(this, "item1 select", Toast.LENGTH_SHORT);
                startActivity(intent);
        }
        switch (item.getItemId()){
            case R.id.menu1:
                Intent intent = new Intent(Edit_profile.this, Edit_profile.class);
                startActivity(intent);

        }
        switch (item.getItemId()){
            case R.id.menu2:
                Intent intent = new Intent(Edit_profile.this, View_profile.class);
                startActivity(intent);

        }
        switch (item.getItemId()){
            case R.id.menu3:
                Intent intent = new Intent(Edit_profile.this, MainActivity.class);
                startActivity(intent);

        }



        return super.onOptionsItemSelected(item);





    }
}


