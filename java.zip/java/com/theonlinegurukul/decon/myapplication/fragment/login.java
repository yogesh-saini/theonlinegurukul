package com.theonlinegurukul.decon.myapplication.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.theonlinegurukul.decon.myapplication.R;

public class login extends Fragment {
    //        implements View.OnClickListener {
    private Button tuition;

    public login() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        getActivity().setTitle("Login");
        final View v = inflater.inflate(R.layout.fragment_login, container, false);

    tuition =(Button) v.findViewById(R.id.tution);
    tuition.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            FragmentTransaction fr= getFragmentManager().beginTransaction();
            fr.replace(R.id.frame,new Login_2()).addToBackStack(null).commit();
        }
    });


        /*
        teacher = (ImageView) v.findViewById(R.id.teacher);
        student = (ImageView) v.findViewById(R.id.student);
        student.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction fr = getFragmentManager().beginTransaction();
                fr.replace(R.id.frame, new stud1()).addToBackStack(null).commit();
            }
        });
        teacher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction fr = getFragmentManager().beginTransaction();
                fr.replace(R.id.frame, new Teach1()).addToBackStack(null).commit();
            }
        });
*/
//            @Override
//            public void onClick(View view) {
//                Intent intent = new Intent(getActivity(),student.class);
//                 startActivity(intent);
//
//                  Toast.makeText(getActivity(),"clicked",Toast.LENGTH_SHORT).show();
//
//
//            }
//        });

        return v;

    }
}
//    @Override
//    public void onClick(View v) {
//Intent intent = new Intent(getActivity(),Teacher.class);
//        Intent i = new Intent(getActivity(),student.class);
//        startActivity(i);
//startActivity(intent);
//    }
//        Intent i;
//        switch (v.getId()) {
//            case R.id.student:
//                i = new Intent(getActivity(), Student.class);
//                getActivity().startActivity(i);
//                break;
//            case R.id.teacher:
//                i = new Intent(getActivity(), Teacher.class);
//                getActivity().startActivity(i);
//                break;
//            default:
//                break;

//        }

//    }
//}








