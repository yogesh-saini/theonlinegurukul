package com.theonlinegurukul.decon.myapplication.fragment;

import com.basgeekball.awesomevalidation.ValidationHolder;

/**
 * Created by Decon on 7/3/2018.
 */

public interface CustomErrorReset {

    void reset(ValidationHolder validationHolder);
}
