package com.theonlinegurukul.decon.myapplication.fragment;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.theonlinegurukul.decon.myapplication.R;

public class howitwork extends Fragment {

    public howitwork() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        getActivity().setTitle("how it work");
        return inflater.inflate(R.layout.fragment_howitwork, container, false);
    }
}
