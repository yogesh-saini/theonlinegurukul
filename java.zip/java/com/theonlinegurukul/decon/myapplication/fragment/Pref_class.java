package com.theonlinegurukul.decon.myapplication.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.theonlinegurukul.decon.myapplication.R;

import java.util.HashMap;
import java.util.Map;

import static com.basgeekball.awesomevalidation.ValidationStyle.COLORATION;

public class Pref_class extends Fragment implements View.OnClickListener,AdapterView.OnItemSelectedListener {
    private Spinner Spinner;
    private Spinner Spinner1;
    private EditText editText;
    private Spinner Spinner2;
    private Spinner Spinner3;
    private EditText editText1;
    private Spinner Spinner4;
    private Spinner Spinner5;
    private EditText editText2;
    private Spinner Spinner6;
    private Spinner Spinner7;
    private EditText editText3;
    private Spinner Spinner8;
    private Spinner Spinner9;
    private EditText editText4;
    private AwesomeValidation awesomeValidation;
    Button next, previous;
    private static final String REGISTER_URL = "http://203.122.21.147/attendance/index.php/cron/test_30";
    public Pref_class() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_pref_class, container, false);
        Spinner = (Spinner) v.findViewById(R.id.spinner1);
        Spinner1 = (Spinner) v.findViewById(R.id.spinner2);
        editText = (EditText) v.findViewById(R.id.edit);
        Spinner2 = (Spinner) v.findViewById(R.id.spinner3);
        Spinner3 = (Spinner) v.findViewById(R.id.spinner4);
        editText1 = (EditText) v.findViewById(R.id.edit1);
        Spinner4 = (Spinner) v.findViewById(R.id.spinner5);
        Spinner5 = (Spinner) v.findViewById(R.id.spinner6);
        editText2 = (EditText) v.findViewById(R.id.edit2);
        Spinner6 = (Spinner) v.findViewById(R.id.spinner7);
        Spinner7 = (Spinner) v.findViewById(R.id.spinner8);
        editText3 = (EditText) v.findViewById(R.id.edit3);
        Spinner8 = (Spinner) v.findViewById(R.id.spinner9);
        Spinner9 = (Spinner) v.findViewById(R.id.spinner10);
        editText4 = (EditText) v.findViewById(R.id.edit4);


        next = (Button) v.findViewById(R.id.next);
        final ViewPager pager = (ViewPager) getActivity().findViewById(R.id.container);
        next.setOnClickListener(this);


               /* @Override
                public void onClick(View view) {
                    pager.setCurrentItem(3);

                }
            });*/

        previous = (Button) v.findViewById(R.id.previous);
        previous.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                pager.setCurrentItem(1);

            }
        });

        String values1[] = {"Primary Subject", "Mathmatics", "Physics", "Chemistry", "Biology", "science", "Computer", "Hindi", "English",
        };
        Spinner spinner1 = (Spinner) v.findViewById(R.id.spinner1);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values1);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinner1.setAdapter(adapter1);

        String values2[] = {"Secondary Subject", "Mathmatics", "Physics", "Chemistry", "Biology", "science", "Computer", "Hindi", "English",
        };
        Spinner spinner2 = (Spinner) v.findViewById(R.id.spinner2);
        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values2);
        adapter2.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner2.setAdapter(adapter2);


        String values3[] = {"Primary Subject", "Mathmatics", "Physics", "Chemistry", "Biology", "science", "Computer", "Hindi", "English",
        };
        Spinner spinner3 = (Spinner) v.findViewById(R.id.spinner3);
        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values3);
        adapter3.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner3.setAdapter(adapter3);

        String values4[] = {"Secondary Subject", "Mathmatics", "Physics", "Chemistry", "Biology", "science", "Computer", "Hindi", "English",
        };
        Spinner spinner4 = (Spinner) v.findViewById(R.id.spinner4);
        ArrayAdapter<String> adapter4 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values4);
        adapter4.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner4.setAdapter(adapter4);

        String values5[] = {"Primary Subject", "Mathmatics", "Physics", "Chemistry", "Biology", "science", "Computer", "Hindi", "English",
        };
        Spinner spinner5 = (Spinner) v.findViewById(R.id.spinner5);
        ArrayAdapter<String> adapter5 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values5);
        adapter5.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner5.setAdapter(adapter5);


        String values6[] = {"Secondary Subject", "Mathmatics", "Physics", "Chemistry", "Biology", "science", "Computer", "Hindi", "English",
        };
        Spinner spinner6 = (Spinner) v.findViewById(R.id.spinner6);
        ArrayAdapter<String> adapter6 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values6);
        adapter6.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner6.setAdapter(adapter6);

        String values7[] = {"Primary Subject", "Mathmatics", "Physics", "Chemistry", "Biology", "science", "Computer", "Hindi", "English",
        };
        Spinner spinner7 = (Spinner) v.findViewById(R.id.spinner7);
        ArrayAdapter<String> adapter7 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values7);
        adapter7.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner7.setAdapter(adapter7);

        String values8[] = {"Secondary Subject", "Mathmatics", "Physics", "Chemistry", "Biology", "science", "Computer", "Hindi", "English",
        };
        Spinner spinner8 = (Spinner) v.findViewById(R.id.spinner8);
        ArrayAdapter<String> adapter8 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values8);
        adapter8.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner8.setAdapter(adapter8);

        String values9[] = {"Primary Subject", "Mathmatics", "Physics", "Chemistry", "Biology", "science", "Computer", "Hindi", "English",
        };
        Spinner spinner9 = (Spinner) v.findViewById(R.id.spinner9);
        ArrayAdapter<String> adapter9 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values9);
        adapter9.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner9.setAdapter(adapter9);

        String values10[] = {"Secondary Subject", "Mathmatics", "Physics", "Chemistry", "Biology", "science", "Computer", "Hindi", "English",
        };
        Spinner spinner10 = (Spinner) v.findViewById(R.id.spinner10);
        ArrayAdapter<String> adapter10 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values10);
        adapter10.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner10.setAdapter(adapter8);


        return v;
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        // On selecting a spinner item
        String item = parent.getItemAtPosition(position).toString();

        // Showing selected spinner item
        Toast.makeText(parent.getContext(), "Selected: " + item, Toast.LENGTH_LONG).show();

    }

    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void onClick(View view) {
        if (view == next) ;
        usernext();
    }


    private void usernext() {

        String spinner1 = Spinner.getSelectedItem().toString().trim().toLowerCase();
        String spinner2 = Spinner1.getSelectedItem().toString().trim().toLowerCase();
        String edit = editText.getText().toString().trim().toLowerCase();

        String spinner3 = Spinner2.getSelectedItem().toString().trim().toLowerCase();
        String spinner4 = Spinner3.getSelectedItem().toString().trim().toLowerCase();
        String edit1 = editText1.getText().toString().trim().toLowerCase();

        String spinner5 = Spinner4.getSelectedItem().toString().trim().toLowerCase();
        String spinner6 = Spinner5.getSelectedItem().toString().trim().toLowerCase();
        String edit2 = editText2.getText().toString().trim().toLowerCase();

        String spinner7 = Spinner6.getSelectedItem().toString().trim().toLowerCase();
        String spinner8 = Spinner7.getSelectedItem().toString().trim().toLowerCase();
        String edit3 = editText3.getText().toString().trim().toLowerCase();

        String spinner9 = Spinner8.getSelectedItem().toString().trim().toLowerCase();
        String spinner10 = Spinner9.getSelectedItem().toString().trim().toLowerCase();
        String edit4 = editText4.getText().toString().trim().toLowerCase();

        awesomeValidation = new AwesomeValidation(COLORATION);
        awesomeValidation.addValidation(getActivity(), R.id.edit, "[a-zA-Z\\s]+", R.string.err_name);
        awesomeValidation.addValidation(getActivity(), R.id.edit1, "\\d+", R.string.err_lname);
        awesomeValidation.addValidation(getActivity(), R.id.edit2, "[a-zA-Z\\s]+", R.string.err_lname);
        awesomeValidation.addValidation(getActivity(), R.id.edit3, "[a-zA-Z\\s]+", R.string.err_lname);
        awesomeValidation.addValidation(getActivity(), R.id.edit4, "[a-zA-Z\\s]+", R.string.err_lname);
        awesomeValidation.validate();

        nextclick(edit, edit1, edit2, edit3, edit4, spinner1, spinner2, spinner3, spinner4, spinner5, spinner6, spinner7, spinner8, spinner9, spinner10);
    }

    private void nextclick(final String edit, final String edit1, final String edit2, final String edit3, final String edit4, final String spinner1, final String spinner2, final String spinner3, final String spinner4, final String spinner5, final String spinner6, final String spinner7, final String spinner8, final String spinner9, final String spinner10) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, REGISTER_URL,
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(getActivity(), response, Toast.LENGTH_LONG).show();

                    }
                },
                new com.android.volley.Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), error.toString(), Toast.LENGTH_LONG).show();
                    }
                }) {


            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<String, String>();
                map.put("spinner1", spinner1);
                map.put("spinner2", spinner2);
                map.put("other", edit);
                map.put("spinner3", spinner3);
                map.put("spinner4", spinner4);
                map.put("other1", edit1);
                map.put("spinner5", spinner5);
                map.put("spinner6", spinner6);
                map.put("other2", edit2);
                map.put("spinner7", spinner7);
                map.put("spinner8", spinner8);
                map.put("other3", edit3);
                map.put("spinner9", spinner9);
                map.put("spinner10", spinner10);
                map.put("other4", edit4);

                return map;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(getActivity().getApplicationContext());
        requestQueue.add(stringRequest);
    }
}