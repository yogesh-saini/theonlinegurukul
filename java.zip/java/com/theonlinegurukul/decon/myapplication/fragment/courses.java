package com.theonlinegurukul.decon.myapplication.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.CardView;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.daimajia.slider.library.Animations.DescriptionAnimation;
import com.daimajia.slider.library.SliderLayout;
import com.daimajia.slider.library.SliderTypes.BaseSliderView;
import com.daimajia.slider.library.SliderTypes.TextSliderView;
import com.daimajia.slider.library.Tricks.ViewPagerEx;
import com.theonlinegurukul.decon.myapplication.R;
import com.theonlinegurukul.decon.myapplication.c_exam1;
import com.theonlinegurukul.decon.myapplication.cbse1;
import com.theonlinegurukul.decon.myapplication.icse1;

import java.util.HashMap;


public class courses extends Fragment implements View.OnClickListener,
        BaseSliderView.OnSliderClickListener,ViewPagerEx.OnPageChangeListener {
    //    ViewPager viewPager;
//   Button button;
    private CardView cbse, sbse, icse, c_exams;
    private FragmentManager fragmentManager;
    private ViewPager sViewPager;
    private LinearLayout dotsLayout;
    private TextView dots[];

    SliderAdapter_new sliderAdapter;


    public courses() {
        // Required empty public constructor
    }

    SliderLayout sliderLayout;
    HashMap<String, String> HashMapForURL;
    HashMap<String, Integer> HashMapForLocalRes;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        getActivity().setTitle("Courses We Offer");
        View v = inflater.inflate(R.layout.fragment_courses, container, false);
        sliderLayout = (SliderLayout) v.findViewById(R.id.slider);
        //Call this method if you want to add images from URL .
        AddImagesUrlOnline();
        //Call this method to add images from local drawable folder .
        AddImageUrlFormLocalRes();
        //Call this method to stop automatic sliding.
        sliderLayout.stopAutoCycle();

        for (String name : HashMapForURL.keySet()) {
            TextSliderView textSliderView = new TextSliderView(getActivity());
            textSliderView
//                    .description(name)
                    .image(HashMapForURL.get(name))
                    .setScaleType(BaseSliderView.ScaleType.Fit)
                    .setOnSliderClickListener(this);
            textSliderView.bundle(new Bundle());
            textSliderView.getBundle()
                    .putString("extra", name);
            sliderLayout.addSlider(textSliderView);
        }

        sliderLayout.setPresetTransformer(SliderLayout.Transformer.DepthPage);
        sliderLayout.setPresetIndicator(SliderLayout.PresetIndicators.Center_Bottom);
        sliderLayout.setCustomAnimation(new DescriptionAnimation());
        sliderLayout.setDuration(3000);
        sliderLayout.addOnPageChangeListener(courses.this);

        icse = (CardView) v.findViewById(R.id.icse);
        cbse = (CardView) v.findViewById(R.id.cbse);
       /* sbse = (CardView) v.findViewById(R.id.sbse);*/
        c_exams = (CardView) v.findViewById(R.id.c_exam);


        icse.setOnClickListener(this);
        cbse.setOnClickListener(this);
        /*sbse.setOnClickListener(this);
        */c_exams.setOnClickListener(this);
        sViewPager = (ViewPager) v.findViewById(R.id.sViewPager);
        dotsLayout = (LinearLayout) v.findViewById(R.id.layoutDots);


        initView();


        // create Adapter object
        sliderAdapter = new SliderAdapter_new(getActivity());
        // set adapter in ViewPager
        sViewPager.setAdapter(sliderAdapter);
        // set PageChangeListener
        sViewPager.addOnPageChangeListener(viewPagerPageChangeListener);

        // adding bottom dots -> addBottomDots(0);
//      addDotIndicator(0);
        addBottomDots(0);
        return v;

    }


//    private void launchHomeScreen() {
//        startActivity(new Intent(getActivity(), courses.class));
//        finish();


//    }

    private int getItem(int i) {
        return sViewPager.getCurrentItem() + i;
    }

    private void initView() {
//        sViewPager = (ViewPager) v.findViewById(R.id.sViewPager);
//        dotsLayout = (LinearLayout) v.findViewById(R.id.layoutDots);

//
        //        btnSkip = (Button) findViewById(R.id.btn_skip);
//        btnNext = (Button) findViewById(R.id.btn_next);


    }

        // viewPagerPage ChangeListener according to Dots-Points
    ViewPager.OnPageChangeListener viewPagerPageChangeListener = new ViewPager.OnPageChangeListener() {

        @Override
        public void onPageSelected(int position) {
            addBottomDots(position);

        // changing the next button text 'NEXT' / 'GOT IT'
            if (position == sliderAdapter.image_slide.length - 1) {
//                 last page. make button text to GOT IT
//                btnNext.setText(getString(R.string.start));
//                btnSkip.setVisibility(View.GONE);
            } else {
//                 still pages are left
//                btnNext.setText(getString(R.string.next));
//                btnSkip.setVisibility(View.VISIBLE);


            }


        }

        @Override
         public void onPageScrolled(int arg0, float arg1, int arg2) {

        }

        @Override
        public void onPageScrollStateChanged(int arg0) {

        }
    };


        // add dot indicator
    public void addDotIndicator(){
        dots = new TextView[4];
        for (int i=0; i<dots.length; i++){
            dots[i] = new TextView(getActivity());
            dots[i].setText(Html.fromHtml("&#8266;"));
            dots[i].setTextSize(35);
            dots[i].setTextColor(getResources().getColor(R.color.white));

            dotsLayout.addView(dots[i]);
        }
    }

        // set of Dots points
    private void addBottomDots(int currentPage) {
//        dots = new TextView[layouts.length];
        dots = new TextView[4];
        dotsLayout.removeAllViews();
        for (int i = 0; i < dots.length; i++) {
            dots[i] = new TextView(getActivity());
            dots[i].setText(Html.fromHtml("&#8226;"));
            dots[i].setTextSize(35);
            dots[i].setTextColor(getResources().getColor(R.color.white));  // dot_inactive
            dotsLayout.addView(dots[i]);
        }

        if (dots.length > 0)
            dots[currentPage].setTextColor(getResources().getColor(R.color.colorAccent)); // dot_active
    }






    @Override
    public void onClick(View v) {
        Intent i;

        switch (v.getId()) {
            case R.id.icse:
                i = new Intent(getActivity(), icse1.class);
                getActivity().startActivity(i);
                break;
            case R.id.cbse:
                i = new Intent(getActivity(), cbse1.class);
                getActivity().startActivity(i);
                break;
          /*  case R.id.sbse:
                i = new Intent(getActivity(), sbse1.class);
                getActivity().startActivity(i);
                break;
          */  case R.id.c_exam:
                i = new Intent(getActivity(), c_exam1.class);
                getActivity().startActivity(i);
                break;
            default:
                break;

        }



    }

    @Override
    public void onStop() {
        sliderLayout.stopAutoCycle();
        super.onStop();
    }

    @Override
    public void onSliderClick(BaseSliderView slider) {
        Toast.makeText(getActivity(), slider.getBundle().get("extra") + "", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
    }

    @Override
    public void onPageSelected(int position) {
        Log.d("Slider Demo", "Page Changed: " + position);
    }

    @Override
    public void onPageScrollStateChanged(int state) {
    }


    public void AddImagesUrlOnline() {

        HashMapForURL = new HashMap<String, String>();
        HashMapForURL.put("THEONLINEGURUKUL", "https://theonlinegurukul.com/assets/web/img/home/slider/slider_image_2.jpg");
        HashMapForURL.put("THEONLINEGURUKUL1", "https://theonlinegurukul.com/assets/web/img/home/slider/slider_image_1.jpg");
        HashMapForURL.put("THEONLINEGURUKUL", "https://theonlinegurukul.com/assets/web/img/home/slider/slider_image_4.jpg");
        /*HashMapForURL.put("THEONLINEGURUKUL", "http://203.122.21.147/theonlinegurukul/assets/data/img/1349x402/26.png");
        HashMapForURL.put("THEONLINEGURUKUL3", "http://203.122.21.147/theonlinegurukul/assets/data/img/theme.png");
        HashMapForURL.put("THEONLINEGURUKUL2", "http://203.122.21.147/theonlinegurukul/assets/data/img/1349x402/21.png");
        HashMapForURL.put("THEONLINEGURUKUL1", "http://203.122.21.147/theonlinegurukul/assets/data/img/1349x402/22.png");
*/

    }
    public void AddImageUrlFormLocalRes(){

        HashMapForLocalRes = new HashMap<String, Integer>();
     /*   HashMapForLocalRes.put("theonlinegurukul", R.drawable.tog);
        HashMapForLocalRes.put("Donut", R.drawable.tog1);
        HashMapForLocalRes.put("Eclair", R.drawable.tog2);
     */

        /*   HashMapForLocalRes.put("Froyo", R.drawable.theonlinegurukul3);
        HashMapForLocalRes.put("GingerBread", R.drawable.theonlinegurukul4);
*/




                }
    }


