package com.theonlinegurukul.decon.myapplication.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.theonlinegurukul.decon.myapplication.R;

import java.util.HashMap;
import java.util.Map;

import static com.basgeekball.awesomevalidation.ValidationStyle.COLORATION;
import static com.theonlinegurukul.decon.myapplication.app.AppConfig.REGISTER_URL;

public class Std extends Fragment implements View.OnClickListener,AdapterView.OnItemSelectedListener {
    private EditText name, lname, Phone, Email, pass, cpass, Zip;
    private Spinner spinner1;
    private AwesomeValidation mAwesomeValidation;
/*DatabaseHelper mydb;*/

    Button signup;
    TextView sb;

    public Std() {


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        getActivity().setTitle("student");
        View v = inflater.inflate(R.layout.fragment_std, container, false);
       /* mydb = new DatabaseHelper(getActivity().getApplicationContext());
       */ name = (EditText) v.findViewById(R.id.Name);
        lname = (EditText) v.findViewById(R.id.LName);
        Phone = (EditText) v.findViewById(R.id.phone);
        Email = (EditText) v.findViewById(R.id.email);
        pass = (EditText) v.findViewById(R.id.password);
        cpass = (EditText) v.findViewById(R.id.cpassword);
        spinner1 = (Spinner) v.findViewById(R.id.spinner);
        Zip = (EditText) v.findViewById(R.id.zip);


        signup = (Button) v.findViewById(R.id.signup);
        sb = (TextView) v.findViewById(R.id.sb);
        signup.setOnClickListener(this);

            /*@Override
            public void onClick(View view) {
                FragmentTransaction fr = getFragmentManager().beginTransaction();
                fr.replace(R.id.frame, new stud1()).addToBackStack(null).commit();
            }
        });*/
        sb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction fr = getFragmentManager().beginTransaction();
                fr.replace(R.id.frame, new stud1()).addToBackStack(null).commit();

            }
        });


        String values[] = {"Gender", "Male", "Female", "Other"};

        Spinner spinner = (Spinner) v.findViewById(R.id.spinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner.setAdapter(adapter);


        return v;

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        // On selecting a spinner item
        String item = parent.getItemAtPosition(position).toString();

        // Showing selected spinner item
        Toast.makeText(parent.getContext(), "Selected: " + item, Toast.LENGTH_LONG).show();

    }

    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void onClick(View view) {
        if (view == signup) ;
        usernext();
    }

    private void usernext() {

        String Name = name.getText().toString().trim().toLowerCase();
        String LName = lname.getText().toString().trim().toLowerCase();
        String spinner = spinner1.getSelectedItem().toString().trim().toLowerCase();
        String phone = Phone.getText().toString().trim().toLowerCase();
        String email = Email.getText().toString().trim().toLowerCase();
        String password = pass.getText().toString().trim();
        String cpassword = cpass.getText().toString().trim();
        String zip = Zip.getText().toString().trim();
        mAwesomeValidation = new AwesomeValidation(COLORATION);
        mAwesomeValidation.addValidation(getActivity(), R.id.Name, "[a-zA-Z0-9_-]+", R.string.err_name);
        mAwesomeValidation.addValidation(getActivity(), R.id.LName, "[a-zA-Z0-9_-]+", R.string.err_name);
        mAwesomeValidation.addValidation(getActivity(), R.id.phone, "\\d{10}", R.string.err_phone);
        mAwesomeValidation.addValidation(getActivity(), R.id.email, Patterns.EMAIL_ADDRESS, R.string.err_email);
        mAwesomeValidation.addValidation(getActivity(), R.id.password, "(?=.*[a-z])(?=.*[A-Z])(?=.*[\\d])(?=.*[~`!@#\\$%\\^&\\*\\(\\)\\-_\\+=\\{\\}\\[\\]\\|\\;:\"<>,./\\?]).{8,}", R.string.err_pass);
        mAwesomeValidation.addValidation(getActivity(), R.id.cpassword, String.valueOf(R.id.password), R.string.err_pass);
        mAwesomeValidation.addValidation(getActivity(), R.id.zip, "\\d+", R.string.err_zip);
        mAwesomeValidation.validate();
        nextclick(Name, LName,spinner, phone, email, password, cpassword, zip);
    }

    private void nextclick(final String name, final String lName,final String spinner1, final String phone, final String email, final String password, final String cpassword, final String zip) {


        StringRequest stringRequest = new StringRequest(Request.Method.POST, REGISTER_URL,
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(getActivity(), response, Toast.LENGTH_LONG).show();

                    }
                },
                new com.android.volley.Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), error.toString(), Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<String, String>();
                map.put("name", name);
                map.put("Last name", lName);
                map.put("spinner", spinner1);
                map.put("phone", phone);
                map.put("Email", email);
                map.put("password", password);
                map.put("confirm password", cpassword);
                map.put("ZIP", zip);
                /* map.put("dpstart", dpStart);*/
                return map;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(getActivity().getApplicationContext());
        requestQueue.add(stringRequest);
    }
}