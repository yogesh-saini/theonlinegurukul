package com.theonlinegurukul.decon.myapplication.fragment;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;

import com.theonlinegurukul.decon.myapplication.R;
import com.theonlinegurukul.decon.myapplication.RecyclerViewAdapter;
import com.theonlinegurukul.decon.myapplication.Video;
import com.theonlinegurukul.decon.myapplication.helper.SQLiteHandler;
import com.theonlinegurukul.decon.myapplication.icse1;

import java.util.ArrayList;

import static com.android.volley.VolleyLog.TAG;


public class home extends Fragment implements View.OnClickListener {
    /*SQLiteHandler myDb;*/
    Dialog dialog;
    CardView eigth, ninth, tenth,elevnth, twelfth,courses;;
    TextView close;
    private Toolbar toolbar;
    private RecyclerView mHorizontalRecyclerView;
    private HorizontalRecyclerViewAdapter horizontalAdapter;
    private LinearLayoutManager horizontalLayoutManager;
    Button button;

    private ArrayList<String> mNames = new ArrayList<>();
    private ArrayList<String> mImageUrls = new ArrayList<>();


    VideoView videoHolder;
    MediaController mediaC;

    public home() {
        // Required empty public constructor

    }

//    SliderLayout sliderLayout;
//    HashMap<String, String> HashMapForURL;
//    HashMap<String, Integer> HashMapForLocalRes;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        getActivity().setTitle("Home");
        View v = inflater.inflate(R.layout.fragment_home, container, false);


        dialog = new Dialog(getActivity());
        eigth = (CardView) v.findViewById(R.id.about);
        courses = (CardView) v.findViewById(R.id.courses);
        courses.setOnClickListener(this);
        eigth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ShowPositiviPopup();
            }

            private void ShowPositiviPopup() {
                dialog.setContentView(R.layout.activity_about);
                close = (TextView) dialog.findViewById(R.id.close);
                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();

            }

        });
       /* myDb = new SQLiteHandler(getActivity().getApplicationContext());
       */
        toolbar = (Toolbar) v.findViewById(R.id.toolbar);

        button = (Button) v.findViewById(R.id.click);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.setContentView(R.layout.activity_video);
                close = (TextView) dialog.findViewById(R.id.close);
                close.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();

            }

        });

        return v;
                                  }

        /*mHorizontalRecyclerView = (RecyclerView) v.findViewById(R.id.horizontalRecyclerView);*/
//        setSupportActionBar(toolbar);


/*
        horizontalAdapter = new HorizontalRecyclerViewAdapter(fillWithData(), getActivity());

        horizontalLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        mHorizontalRecyclerView.setLayoutManager(horizontalLayoutManager);
        mHorizontalRecyclerView.setAdapter(horizontalAdapter);
*/



               public ArrayList<ImageModel> fillWithData() {
                   ArrayList<ImageModel> imageModelArrayList = new ArrayList<>();
                   ImageModel imageModel0 = new ImageModel();
                   imageModel0.setId(System.currentTimeMillis());
                   imageModel0.setImagePath(R.drawable.hom1);
                   imageModelArrayList.add(imageModel0);

                   ImageModel imageModel1 = new ImageModel();
                   imageModel1.setId(System.currentTimeMillis());
                   imageModel1.setImagePath(R.drawable.hom);
                   imageModelArrayList.add(imageModel1);

                   ImageModel imageModel2 = new ImageModel();
                   imageModel2.setId(System.currentTimeMillis());
                   imageModel2.setImagePath(R.drawable.hom3);
                   imageModelArrayList.add(imageModel2);

                   ImageModel imageModel3 = new ImageModel();
                   imageModel3.setId(System.currentTimeMillis());
                   imageModel3.setImagePath(R.drawable.hom4);
                   imageModelArrayList.add(imageModel3);

                   ImageModel imageModel4 = new ImageModel();
                   imageModel4.setId(System.currentTimeMillis());
                   imageModel4.setImagePath(R.drawable.tution);
                   imageModelArrayList.add(imageModel4);

                   ImageModel imageModel5 = new ImageModel();
                   imageModel5.setId(System.currentTimeMillis());
                   imageModel5.setImagePath(R.drawable.im);
                   imageModelArrayList.add(imageModel5);
                   return imageModelArrayList;
               }

//        @Override
//        public boolean onCreateOptionsMenu(Menu menu) {
//             Inflate the menu; this adds items to the action bar if it is present.
//            getMenuInflater().inflate(R.menu.main, menu);
//            return true;
//        }

               @Override
               public boolean onOptionsItemSelected(MenuItem item) {
                   // Handle action bar item clicks here. The action bar will
                   // automatically handle clicks on the Home/Up button, so long
                   // as you specify a parent activity in AndroidManifest.xml.
                   //http://whats-online.info/science-and-tutorials/87/Android-tutorial-Horizontal-RecyclerView-with-images-and-text-example/
                   int id = item.getItemId();

                   //noinspection SimplifiableIfStatement
                   if (id == R.id.action_settings) {
                       return true;
                   }

                   return super.onOptionsItemSelected(item);


               }
          @Override
          public void onClick(View v) {
              Intent i;

              switch (v.getId()) {
                  case R.id.click:
                      i = new Intent(getActivity(), Video.class);
                      getActivity().startActivity(i);
                      break;

                      case R.id.courses:
                          i = new Intent(getActivity(), icse1.class);
                          getActivity().startActivity(i);
                          break;

                      default:
                      break;

              }

          }
      }

























