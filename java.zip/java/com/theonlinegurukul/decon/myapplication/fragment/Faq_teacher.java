package com.theonlinegurukul.decon.myapplication.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.theonlinegurukul.decon.myapplication.R;

public class Faq_teacher extends Fragment{
    /*FragmentStatePagerAdapter
} {*/
    /*String[] titles = new String[]{"FAQ_Teacher","FAQ_Student"};
     public Faq_teacher(FragmentManager fm) {
         super(fm);
     }

    *//* @Override
    public CharSequence getPageTitle(int position) {
        return titles[position];
    }

    @Override
    public int getCount() {
        return 0;
    }
*/
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup frame,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View v = inflater.inflate(R.layout.fragment_faq_teacher, frame, false);
        return v;
    }

}/*  @Override
    public Fragment getItem(int position) {
        switch (position){
            case 0:
                about fragment =new about();
                return fragment;
            case 1:
                Faq_student faqStudent = new Faq_student();
                return faqStudent;
        }

        return null;
    }

    public static Fragment newInstance(int i, String faq_teacher) {
    }
}
*/