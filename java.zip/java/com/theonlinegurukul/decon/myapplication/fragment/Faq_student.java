package com.theonlinegurukul.decon.myapplication.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.theonlinegurukul.decon.myapplication.R;

public class Faq_student extends Fragment {

    public Faq_student() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup frame,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
         View v = inflater.inflate(R.layout.fragment_faq_student, frame, false);
        return v;
    }
}
