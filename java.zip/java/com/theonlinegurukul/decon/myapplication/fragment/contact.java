package com.theonlinegurukul.decon.myapplication.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.theonlinegurukul.decon.myapplication.R;


public class contact extends Fragment implements OnMapReadyCallback, View.OnClickListener {
    Button contact, message;
    private GoogleMap mMap;

    public contact() {
        // Required empty public constructor
    }


    String[] values =
            {"Select Country","Afghanistan", "Albania", "Algeria",
                    "Andorra", "Angola", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba",
                    "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium",
                    "Belize", "Benin",
                    "Bhutan", "Bolivia", "Bosnia and Herzegovina", "Botswana", "Brazil", "Brunei", "Bulgaria", "Burkina Faso", "Burma", "Burundi", "Cambodia", "Cameroon",
                    "Canada", "Cabo Verde",
                    "Central African Republic",
                    "Chad",
                    "Chile", "China", "Colombia", "Comoros", "Costa Rica", "Cote d'Ivoire", "Croatia", "Cuba", "Curacao", "Cyprus",
                    "Czechia",
                    "Denmark", "Djibouti", "Dominica", "Dominican Republic", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea",
                    "Estonia",
                    "Ethiopia", "Fiji", "Finland", "France", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Greece", "Grenada",
                    "Guatemala",
                    "Guinea",
                    "Guinea-Bissau", "Guyana", "Haiti", "Holy See", "Honduras", "Hong Kong", "Hungary", "Iceland", "India",
                    "Indonesia",
                    "Iran", "Iraq", "Ireland", "Israel", "Italy", "Jamaica",
                    "Japan",
                    "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea, North", "Korea, South", "Kosovo", "Kuwait", "Kyrgyzstan", "Laos", "Latvia", "Lebanon",
                    "Lesotho",
                    "Liberia", "Libya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau", "Macedonia", "Madagascar", "Malawi",
                    "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Mauritania", "Mauritius", "Mexico", "Micronesia", "Moldova", "Monaco",
                    "Mongolia",
                    "Montenegro", "Morocco", "Mozambique", "Namibia", "Nauru",
                    "Nepal",
                    "Netherlands", "New Zealand", "Nicaragua", "Niger", "Nigeria", "North Korea", "Norway", "Oman", "Pakistan", "Palau",
                    "Palestinian Territories", "Panama", "Papua New Guinea", "Paraguay",
                    "Peru",
                    "Philippines", "Poland", "Portugal", "Qatar", "Romania", "Russia", "Rwanda", "Saint Kitts and Nevis",
                    "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa",
                    "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Serbia", "Seychelles", "Sierra Leone", "Singapore", "Sint Maarten",
                    "Slovakia", "Slovenia", "Solomon Islands", "Somalia",
                    "South Africa", "South Korea", "South Sudan", "Spain",
                    "Sri Lanka", "Sudan", "Suriname", "Swaziland",
                    "Sweden", "Switzerland", "Syria", "Taiwan", "Tajikistan", "Tanzania", "Thailand", "Timor-Leste", "Togo", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "Uruguay", "Uzbekistan", "Vanuatu",
                    "Venezuela", "Vietnam", "Yemen", "Zambia", "Zimbabwe",
            };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        getActivity().setTitle("Contact");

        View v = inflater.inflate(R.layout.fragment_contact, container, false);


        SupportMapFragment supportMapFragment = ((SupportMapFragment)
                getChildFragmentManager().findFragmentById(R.id.map));
        supportMapFragment.getMapAsync(this);

        Spinner spinner = (Spinner) v.findViewById(R.id.spinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner.setAdapter(adapter);

        String values1[] = {"What describes you best?", "Individual Teacher or Trainer", "Learner or Student"};
        Spinner spinner2 = (Spinner) v.findViewById(R.id.spinner2);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values1);
        adapter1.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner2.setAdapter(adapter1);

        contact = (Button) v.findViewById(R.id.contactUs);
        message = (Button) v.findViewById(R.id.message);
        message.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {
                Intent i;
                Toast.makeText(getActivity(), "send", Toast.LENGTH_SHORT).show();

            }
        });


        contact.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {
                Intent i;
                Toast.makeText(getActivity(), "clicked", Toast.LENGTH_SHORT).show();
            }
        });


        return v;
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {

        if(googleMap != null){
            mMap = googleMap;
            mMap.getUiSettings().setMapToolbarEnabled(true);
        }

//         Add a marker in Sydney and move the camera
        LatLng ggn = new LatLng(28.49402, 77.079899);
        mMap.addMarker(new MarkerOptions().position(ggn).title("The Online Gurukul"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(ggn));
        mMap.animateCamera(CameraUpdateFactory.zoomTo(15));



    }


    @Override
    public void onClick(View v) {
        ScrollView sv = (ScrollView) v.findViewById(R.id.scroll);
        sv.scrollTo(0, sv.getBottom());


    }
}


