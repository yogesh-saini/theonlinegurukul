package com.theonlinegurukul.decon.myapplication.fragment;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationHolder;
import com.theonlinegurukul.decon.myapplication.R;

import java.util.HashMap;
import java.util.Map;

import static com.basgeekball.awesomevalidation.ValidationStyle.COLORATION;

public class Qualification extends Fragment implements View.OnClickListener,AdapterView.OnItemSelectedListener {
    Button next, previous;
    private ScrollView mScrollView;
    private Spinner Spinner;
    private EditText editText;
    private EditText editText1;
    private EditText editText2;
    private Spinner Spinner1;
    private EditText Univ;
    private EditText YOP;
    private EditText GRD;
    private Spinner Spinner2;
    private EditText Univ1;
    private EditText YOP1;
    private EditText GRD1;
    private Spinner Spinner3;
    private EditText Univ2;
    private EditText YOP2;
    private EditText GRD2;
    private Spinner Spinner4;
    private EditText Univ3;
    private EditText YOP3;
    private EditText GRD3;
    private AwesomeValidation awesomeValidation;
    private static final String REGISTER_URL = "http://203.122.21.147/attendance/index.php/cron/test_30";

    public Qualification() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_qualification, container, false);
        Spinner = (Spinner) v.findViewById(R.id.spinner);
        editText = (EditText) v.findViewById(R.id.university);
        editText1 = (EditText) v.findViewById(R.id.passing_year);
        editText2 = (EditText) v.findViewById(R.id.edit);

        Spinner1 = (Spinner) v.findViewById(R.id.spinner1);
        Univ = (EditText) v.findViewById(R.id.university1);
        YOP = (EditText) v.findViewById(R.id.passing_year1);
        GRD = (EditText) v.findViewById(R.id.grade);

        Spinner2 = (Spinner) v.findViewById(R.id.spinner2);
        Univ1 = (EditText) v.findViewById(R.id.university2);
        YOP1 = (EditText) v.findViewById(R.id.passing_year2);
        GRD1 = (EditText) v.findViewById(R.id.grade1);

        Spinner3 = (Spinner) v.findViewById(R.id.spinner3);
        Univ2 = (EditText) v.findViewById(R.id.university3);
        YOP2 = (EditText) v.findViewById(R.id.passing_year3);
        GRD2 = (EditText) v.findViewById(R.id.grade2);

        Spinner4 = (Spinner) v.findViewById(R.id.spinner4);
        Univ3 = (EditText) v.findViewById(R.id.university4);
        YOP3 = (EditText) v.findViewById(R.id.passing_year4);
        GRD3 = (EditText) v.findViewById(R.id.grade3);

        mScrollView = (ScrollView) v.findViewById(R.id.scroll);


        next = (Button) v.findViewById(R.id.next);

        final ViewPager pager = (ViewPager) getActivity().findViewById(R.id.container);
        next.setOnClickListener(this);


          /*  @Override
            public void onClick(View view) {
                pager.setCurrentItem(2);

            }
        });
*/
        previous = (Button) v.findViewById(R.id.previous);
        previous.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                pager.setCurrentItem(0);

            }
        });

        String values[] = {"Select First Qualification", "11th", "12th", "B.A", "M.A", "B.E", "M.E", "B.Tech", "M.Tech", "B.sc", "M.sc", "BCA", "MCA",
                "BBA", "MBA", "B.Arch", "P.hd", "M.Phill", "BDS", "MDS", "MD", "MBBS", "BPT", "B.Com", "M.Com", "B.pharm", "M.pharm", "CA", "LLB", "ICWA"};

        final Spinner spinner = (Spinner) v.findViewById(R.id.spinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner.setAdapter(adapter);

/*
        Spinner mySpinner = (Spinner)v.findViewById(R.id.spinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        mySpinner.setAdapter(adapter);

        int selectedItemOfMySpinner = mySpinner.getSelectedItemPosition();
        String actualPositionOfMySpinner = (String) mySpinner.getItemAtPosition(selectedItemOfMySpinner);

        if (actualPositionOfMySpinner.isEmpty()) {
          //  setSpinnerError(mySpinner,("field can't be empty"));
            Toast.makeText(getActivity(),"error",Toast.LENGTH_LONG).show();
        }
*/


/*

        awesomeValidation.addValidation(getActivity(), R.id.spinner, new CustomValidation() {
            @Override
            public boolean compare(ValidationHolder validationHolder) {
                if (((Spinner) validationHolder.getView()).getSelectedItem().toString().equals("< Please select one >")) {
                    return false;
                } else {
                    return true;
                }
            }
        }, new CustomValidationCallback() {
            @Override
            public void execute(ValidationHolder validationHolder) {
                TextView textViewError = (TextView) ((Spinner) validationHolder.getView()).getSelectedView();
                textViewError.setError(validationHolder.getErrMsg());
                textViewError.setTextColor(Color.RED);
            }
        }, new CustomErrorReset() {
            @Override
            public void reset(ValidationHolder validationHolder) {
                TextView textViewError = (TextView) ((Spinner) validationHolder.getView()).getSelectedView();
                textViewError.setError(null);
                textViewError.setTextColor(Color.BLACK);
            }
        }, R.string.err_spinner);
*/



        String values1[] = {"Select Second Qualification", "11th", "12th", "B.A", "M.A", "B.E", "M.E", "B.Tech", "M.Tech", "B.sc", "M.sc", "BCA", "MCA",
                "BBA", "MBA", "B.Arch", "P.hd", "M.Phill", "BDS", "MDS", "MD", "MBBS", "BPT", "B.Com", "M.Com", "B.pharm", "M.pharm", "CA", "LLB", "ICWA"};
        Spinner spinner1 = (Spinner) v.findViewById(R.id.spinner1);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values1);
        adapter1.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner1.setAdapter(adapter1);


        String values2[] = {"Select third Qualification", "11th", "12th", "B.A", "M.A", "B.E", "M.E", "B.Tech", "M.Tech", "B.sc", "M.sc", "BCA", "MCA",
                "BBA", "MBA", "B.Arch", "P.hd", "M.Phill", "BDS", "MDS", "MD", "MBBS", "BPT", "B.Com", "M.Com", "B.pharm", "M.pharm", "CA", "LLB", "ICWA"};
        Spinner spinner2 = (Spinner) v.findViewById(R.id.spinner2);
        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values2);
        adapter2.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner2.setAdapter(adapter2);

        String values3[] = {"Select Fourth Qualification", "11th", "12th", "B.A", "M.A", "B.E", "M.E", "B.Tech", "M.Tech", "B.sc", "M.sc", "BCA", "MCA",
                "BBA", "MBA", "B.Arch", "P.hd", "M.Phill", "BDS", "MDS", "MD", "MBBS", "BPT", "B.Com", "M.Com", "B.pharm", "M.pharm", "CA", "LLB", "ICWA"};
        Spinner spinner3 = (Spinner) v.findViewById(R.id.spinner3);
        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values3);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner3.setAdapter(adapter3);

        String values4[] = {"Select Fifth Qualification", "11th", "12th", "B.A", "M.A", "B.E", "M.E", "B.Tech", "M.Tech", "B.sc", "M.sc", "BCA", "MCA",
                "BBA", "MBA", "B.Arch", "P.hd", "M.Phill", "BDS", "MDS", "MD", "MBBS", "BPT", "B.Com", "M.Com", "B.pharm", "M.pharm", "CA", "LLB", "ICWA"};
        Spinner spinner4 = (Spinner) v.findViewById(R.id.spinner4);
        ArrayAdapter<String> adapter4 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values4);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner4.setAdapter(adapter4);

        return v;

    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        // On selecting a spinner item
        String item = parent.getItemAtPosition(1).toString();

        // Showing selected spinner item
        Toast.makeText(getActivity().getApplicationContext(), "Selected: " + item, Toast.LENGTH_LONG).show();

    }

    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void onClick(View view) {
        if (view == next) ;
        usernext();
    }

    private void usernext() {

        String spinner = Spinner.getSelectedItem().toString().trim().toLowerCase();
        String university = editText.getText().toString().trim().toLowerCase();
        String passing_year = editText1.getText().toString().trim().toLowerCase();
        String edit = editText2.getText().toString().trim().toLowerCase();

        String spinner1 = Spinner1.getSelectedItem().toString().trim().toLowerCase();
        String university1 = Univ.getText().toString().trim().toLowerCase();
        String passing_year1 = YOP.getText().toString().trim().toLowerCase();
        String grade = GRD.getText().toString().trim();

        String spinner2 = Spinner2.getSelectedItem().toString().trim().toLowerCase();
        String university2 = Univ1.getText().toString().trim();
        String passing_year2 = YOP1.getText().toString().trim().toLowerCase();
        String grade1 = GRD1.getText().toString().trim().toLowerCase();

        String spinner3 = Spinner3.getSelectedItem().toString().trim().toLowerCase();
        String university3 = Univ2.getText().toString().trim().toLowerCase();
        String passing_year3 = YOP2.getText().toString().trim().toLowerCase();
        String grade2 = GRD2.getText().toString().trim().toLowerCase();

        String spinner4 = Spinner4.getSelectedItem().toString().trim().toLowerCase();
        String university4 = Univ3.getText().toString().trim().toLowerCase();
        String passing_year4 = YOP3.getText().toString().trim().toLowerCase();
        String grade3 = GRD3.getText().toString().trim().toLowerCase();
        awesomeValidation = new AwesomeValidation(COLORATION);
        awesomeValidation.addValidation(getActivity(), R.id.university, "[a-zA-Z\\s]+", R.string.err_name);
        awesomeValidation.addValidation(getActivity(), R.id.passing_year, "\\d+", R.string.err_lname);
        awesomeValidation.addValidation(getActivity(), R.id.edit, "[a-zA-Z\\s]+", R.string.err_lname);

        awesomeValidation.addValidation(getActivity(), R.id.university1, "[a-zA-Z\\s]+", R.string.err_lname);
        awesomeValidation.addValidation(getActivity(), R.id.passing_year1, "\\d+", R.string.err_lname);
        awesomeValidation.addValidation(getActivity(), R.id.grade, "[a-zA-Z\\s]+", R.string.err_lname);

        awesomeValidation.addValidation(getActivity(), R.id.university2, "[a-zA-Z\\s]+", R.string.err_lname);
        awesomeValidation.addValidation(getActivity(), R.id.passing_year2, "\\d+", R.string.err_lname);
        awesomeValidation.addValidation(getActivity(), R.id.grade1, "[a-zA-Z\\s]+", R.string.err_lname);

        awesomeValidation.addValidation(getActivity(), R.id.university3, "[a-zA-Z\\s]+", R.string.err_lname);
        awesomeValidation.addValidation(getActivity(), R.id.passing_year3, "\\d+", R.string.err_lname);
        awesomeValidation.addValidation(getActivity(), R.id.grade2, "[a-zA-Z\\s]+", R.string.err_lname);

        awesomeValidation.addValidation(getActivity(), R.id.university4, "[a-zA-Z\\s]+", R.string.err_lname);
        awesomeValidation.addValidation(getActivity(), R.id.passing_year4, "\\d+", R.string.err_lname);
        awesomeValidation.addValidation(getActivity(), R.id.grade3, "[a-zA-Z\\s]+", R.string.err_lname);
        awesomeValidation.validate();

        nextclick(spinner, university, passing_year, edit, spinner1, passing_year1, university1, grade, spinner2, university2, passing_year2, grade1, spinner3, university3, passing_year3, grade2, spinner4, university4, passing_year4, grade3);
    }

    private void nextclick(final String spinner, final String university, final String passing_year, final String edit, final String spinner1, final String passing_year1, final String university1, final String grade, final String spinner2, final String university2, final String passing_year2, final String grade1, final String spinner3, final String university3, final String passing_year3, final String grade2, final String spinner4, final String university4, final String passing_year4, final String grade3) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, REGISTER_URL,
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(getActivity(), response, Toast.LENGTH_LONG).show();

                    }
                },
                new com.android.volley.Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), error.toString(), Toast.LENGTH_LONG).show();
                    }
                }) {


            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<String, String>();
                map.put("spinner", spinner);
                map.put("University", university);
                map.put("Passing year ", passing_year);
                map.put("Grade", edit);
                map.put("spinner1", spinner1);
                map.put("University1", university1);
                map.put("Passing year1 ", passing_year1);
                map.put("Grade1", grade);
                map.put("spinner2", spinner2);
                map.put("University2", university2);
                map.put("Passing year2 ", passing_year2);
                map.put("Grade2", grade1);
                map.put("spinner3", spinner3);
                map.put("University3", university3);
                map.put("Passing year3 ", passing_year3);
                map.put("Grade3", grade2);
                map.put("spinner4", spinner4);
                map.put("University4", university4);
                map.put("Passing year4 ", passing_year4);
                map.put("Grade4", grade3);

                return map;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(getActivity().getApplicationContext());
        requestQueue.add(stringRequest);
    }

    private void setSpinnerError(Spinner spinner, String error){
        View selectedView = spinner.getSelectedView();
        if (selectedView != null && selectedView instanceof TextView) {
            spinner.requestFocus();
            TextView selectedTextView = (TextView) selectedView;
            selectedTextView.setError("error"); // any name of the error will do
            selectedTextView.setTextColor(Color.RED); //text color in which you want your error message to be displayed
            selectedTextView.setText(error); // actual error message
            spinner.performClick(); // to open the spinner list if error is found.

        }
    }
}


