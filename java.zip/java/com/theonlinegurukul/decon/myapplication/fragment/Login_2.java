package com.theonlinegurukul.decon.myapplication.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.theonlinegurukul.decon.myapplication.R;

public class Login_2 extends Fragment {
private ImageView teacher,student;
    public Login_2() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        getActivity().setTitle("Login");
        View v = inflater.inflate(R.layout.fragment_course, container, false);

        teacher = (ImageView) v.findViewById(R.id.teacher);
        student = (ImageView) v.findViewById(R.id.student);
        student.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction fr = getFragmentManager().beginTransaction();
                fr.replace(R.id.frame, new stud1()).addToBackStack(null).commit();
            }
        });
        teacher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction fr = getFragmentManager().beginTransaction();
                fr.replace(R.id.frame, new Teach1()).addToBackStack(null).commit();
            }
        });
//            @Override
//            public void onClick(View view) {
//                Intent intent = new Intent(getActivity(),student.class);
//                 startActivity(intent);
//
//                  Toast.makeText(getActivity(),"clicked",Toast.LENGTH_SHORT).show();
//
//
//            }
//        });

        return v;

    }
}



