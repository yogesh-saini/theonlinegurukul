package com.theonlinegurukul.decon.myapplication.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.theonlinegurukul.decon.myapplication.R;
import java.util.HashMap;
import java.util.Map;

import static com.basgeekball.awesomevalidation.ValidationStyle.COLORATION;
import static com.theonlinegurukul.decon.myapplication.app.AppConfig.REGISTER_URL;

public class Bank_Details extends Fragment implements View.OnClickListener  {

    private EditText Edit;
    private EditText Edit1;
    private EditText Edit2;
    private EditText Edit3;
    private EditText Edit4;
    private EditText Edit5;
    private AwesomeValidation awesomeValidation;
    /*private static final String REGISTER_URL = "http://203.122.21.147/attendance/index.php/cron/test_30";*/
    Button next, previous;

    public Bank_Details() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_bank__details, container, false);


        Edit = (EditText) v.findViewById(R.id.edit);
        Edit1 = (EditText) v.findViewById(R.id.edit1);
        Edit2 = (EditText) v.findViewById(R.id.edit2);
        Edit3 = (EditText) v.findViewById(R.id.edit3);
        Edit4 = (EditText) v.findViewById(R.id.edit4);
        Edit5 = (EditText) v.findViewById(R.id.edit5);


        next = (Button) v.findViewById(R.id.next);
        final ViewPager pager = (ViewPager) getActivity().findViewById(R.id.container);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pager.setCurrentItem(4);

          /*      Other_upload other_upload = new Other_upload();
                Bundle bundle = new Bundle();
                bundle.putString("name","yogi");
                bundle.putString("channel","saini");
                other_upload.setArguments(bundle);
                FragmentManager manager = getFragmentManager();
                manager.beginTransaction().replace(R.id.frame,other_upload).commit();

*/



/*

          String first = Edit.getText().toString();

          Bundle bundle = new Bundle();
          bundle.putString("FirstName", first);

          FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                Other_upload other_upload = new Other_upload();
                other_upload.setArguments(bundle);

                fragmentTransaction.replace(R.id.frame,other_upload);
                fragmentTransaction.commit();
*/


            }
        });
/*
            @Override
            public void onClick(View view) {
                }
        });
*/


        previous = (Button) v.findViewById(R.id.previous);
        previous.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                pager.setCurrentItem(2);

            }
        });


        return v;
    }




    @Override
    public void onClick(View view) {
        if (view == next) ;
        usernext();
    }

    private void usernext() {


        String edit = Edit.getText().toString().trim().toLowerCase();
        String edit1 = Edit1.getText().toString().trim().toLowerCase();
        String edit2 = Edit2.getText().toString().trim().toLowerCase();
        String edit3 = Edit3.getText().toString().trim().toLowerCase();
        String edit4 = Edit4.getText().toString().trim().toLowerCase();
        String edit5 = Edit5.getText().toString().trim().toLowerCase();
        awesomeValidation = new AwesomeValidation(COLORATION);
        awesomeValidation.addValidation(getActivity(), R.id.edit, "[a-zA-Z\\s]", R.string.err_name);
        awesomeValidation.addValidation(getActivity(), R.id.edit1, "[a-zA-Z\\s]", R.string.err_lname);
        awesomeValidation.addValidation(getActivity(), R.id.edit2, "[a-zA-Z\\s]+", R.string.err_lname);
        awesomeValidation.addValidation(getActivity(), R.id.edit3, "\\d+", R.string.err_lname);
        awesomeValidation.addValidation(getActivity(), R.id.edit4, "[a-zA-Z\\s]+\\d+", R.string.err_lname);
        awesomeValidation.addValidation(getActivity(), R.id.edit5, "[a-zA-Z\\s]+\\d+", R.string.err_lname);
        awesomeValidation.validate();
        nextclick(edit, edit1, edit2, edit3, edit4, edit5);
    }

    private void nextclick(final String edit, final String edit1, final String edit2, final String edit3, final String edit4, final String edit5) {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, REGISTER_URL,
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(getActivity(), response, Toast.LENGTH_LONG).show();

                    }
                },
                new com.android.volley.Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), error.toString(), Toast.LENGTH_LONG).show();
                    }
                }) {


            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<String, String>();
                map.put("Bank Name", edit);
                map.put("Branch Name", edit1);
                map.put("Name As in Acc ", edit2);
                map.put("Acc. No.", edit3);
                map.put("Ifsc", edit4);
                map.put("MICR", edit5);
                return map;
            }
        };

    RequestQueue requestQueue = Volley.newRequestQueue(getActivity().getApplicationContext());
        requestQueue.add(stringRequest);


    }


}