package com.theonlinegurukul.decon.myapplication.fragment;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.theonlinegurukul.decon.myapplication.R;


public class ToFragment extends Fragment {

    public ToFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
/*
        Bundle mbundle = new Bundle();
        mbundle= getArguments();
        String test1= mbundle.getString("1");
        String test2= mbundle.getString("2");
        String test3= mbundle.getString("3");
        String test4=  mbundle.getString("4");
        String test5=  mbundle.getString("5");
        String test6=  mbundle.getString("6");
        Toast.makeText(getActivity(),"Null "+test1+test2+test3+test4+test5+test6,Toast.LENGTH_LONG).show();
*/

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_to, container, false);
    }

}
