package com.theonlinegurukul.decon.myapplication.fragment;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.theonlinegurukul.decon.myapplication.R;

/**
 * Created by decon on 2/7/2018.
 */

public class ViewPagerAdapter extends PagerAdapter {

    private Context context;
    private LayoutInflater layoutInflater;
    private Integer[] images = {R.drawable.image1, R.drawable.image2, R.drawable.image3, R.drawable.image4,
            R.drawable.image5};

    public ViewPagerAdapter(Context context) {

        this.context = context;
    }


    @Override
    public int getCount() {

        return images.length;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {

        return view == object;
    }
        @Override
        public Object instantiateItem(ViewGroup container, int position) {

            layoutInflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            View view = layoutInflater.inflate(R.layout.custom_layout,null);
           ImageView imageView =(ImageView) view.findViewById(R.id.imageView);
//            ImageView.setImageResource(images[position]);
//              ImageView imageView =(ImageView) v.findViewById(R.id.imageView);
              imageView.setImageResource(images[position]);


            ViewPager vp =  (ViewPager) container;
            vp.addView(view, 0);
            return view;
        }
    public void destroyItem(ViewGroup container,int position, Object object){

        ViewPager vp = (ViewPager) container;
        View view =(View) object;
        vp.removeView(view);

    }
}



