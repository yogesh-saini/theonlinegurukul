package com.theonlinegurukul.decon.myapplication.fragment;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.nbsp.materialfilepicker.MaterialFilePicker;
import com.nbsp.materialfilepicker.ui.FilePickerActivity;
import com.theonlinegurukul.decon.myapplication.R;

import java.util.HashMap;
import java.util.Map;

import static com.basgeekball.awesomevalidation.ValidationStyle.COLORATION;

public class Other_upload extends Fragment implements View.OnClickListener {

    private EditText Edit;
    private EditText Edit1;
    private Spinner Spinner;
    private Spinner Spinner1;
    private Spinner Spinner2;
    private Spinner Spinner3;
    private Spinner Spinner4;
    private Spinner Spinner5;
    private Spinner Spinner6;
    private Spinner Spinner7;
    private Button Choose_file;
    private Button Fragment;
    private Button activity;
    private AwesomeValidation awesomeValidation;
    private static final String REGISTER_URL = "http://203.122.21.147/attendance/index.php/cron/test_30";

    Button next, previous;
    public static final int PERMISSIONS_REQUEST_CODE = 0;
    public static final int FILE_PICKER_REQUEST_CODE = 1;


    public Other_upload() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


    /*    Bundle bundle = getArguments();
        if(bundle != null);
        String name = bundle.getString("name");

        String channel = bundle.getString("channel");
        Toast.makeText(getContext(), "name" +name + "channel:" +channel ,Toast.LENGTH_SHORT).show();


*/
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_other_upload, container, false);



        Edit = (EditText) v.findViewById(R.id.edit);
        Edit1 = (EditText) v.findViewById(R.id.edit1);

        Spinner = (Spinner) v.findViewById(R.id.spinner);
        Spinner1 = (Spinner) v.findViewById(R.id.spinner1);
        Spinner2 = (Spinner) v.findViewById(R.id.spinner2);
        Spinner3 = (Spinner) v.findViewById(R.id.spinner3);
        Spinner4 = (Spinner) v.findViewById(R.id.spinner4);
        Spinner5 = (Spinner) v.findViewById(R.id.spinner5);
        Spinner6 = (Spinner) v.findViewById(R.id.spinner6);
        Spinner7 = (Spinner) v.findViewById(R.id.spinner7);
        Choose_file = (Button) v.findViewById(R.id.choose_file);
        Fragment = (Button) v.findViewById(R.id.pick_from_fragment);
        activity = (Button) v.findViewById(R.id.pick_from_activity);

        next = (Button) v.findViewById(R.id.next);
        final ViewPager pager = (ViewPager) getActivity().findViewById(R.id.container);
        next.setOnClickListener(this);


  /*          @Override
            public void onClick(View view) {
                pager.setCurrentItem(5);

            }
        });
  */      previous = (Button) v.findViewById(R.id.previous);
        previous.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                pager.setCurrentItem(3);

            }
        });


        Button pickButton = (Button) v.findViewById(R.id.pick_from_fragment);
        Button pickButton1 = (Button) v.findViewById(R.id.choose_file);
        Button pickButton2 = (Button) v.findViewById(R.id.pick_from_activity);
        pickButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkPermissionsAndOpenFilePicker();
            }

        });

        pickButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkPermissionsAndOpenFilePicker();
            }
        });

        pickButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkPermissionsAndOpenFilePicker();
            }
        });

        String values[] = {"Days Available for teacher", "Sunday", "Monday", "Tuesday", "Wednesday", "Thrusday", "Friday", "Saturday"};
        Spinner spinner = (Spinner) v.findViewById(R.id.spinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_list_item_checked, values);
        adapter.setDropDownViewResource(android.R.layout.simple_list_item_checked);
        spinner.setAdapter(adapter);

        String values1[] = {"Hours Daily Available", "0 Hour", "1 Hour", "2 Hour", "3 Hour", "4 Hour", "5 Hour", "6 Hour", "7 Hour", "8 Hour"};
        Spinner spinner1 = (Spinner) v.findViewById(R.id.spinner1);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_dropdown_item, values1);
        adapter1.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner1.setAdapter(adapter1);

        String values2[] = {"Preferred time for teacher", "6-7Am", "7-8Am", "8-9Am", "9-10Am", "10-11Am", "11-12Pm", "2-3Pm", "3-4Pm", "4-5Pm", "5-6Pm", "6-7Pm", "7-8Pm", "8-9Pm"};
        Spinner spinner2 = (Spinner) v.findViewById(R.id.spinner2);
        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_list_item_checked, values2);
        adapter2.setDropDownViewResource(android.R.layout.simple_list_item_checked);
        spinner2.setAdapter(adapter2);

        String values3[] = {"Total Teaching Experience", "Less than one year", "Less than two year", "Less than three year", "More than five year"};
        Spinner spinner3 = (Spinner) v.findViewById(R.id.spinner3);
        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values3);
        adapter3.setDropDownViewResource(android.R.layout.simple_list_item_checked);
        spinner3.setAdapter(adapter3);

        String values4[] = {"Type of connection", "Broadband", "wifi", "Dongle", "Mobile", "cable", "other"};
        Spinner spinner4 = (Spinner) v.findViewById(R.id.spinner4);
        ArrayAdapter<String> adapter4 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values4);
        adapter4.setDropDownViewResource(android.R.layout.simple_list_item_checked);
        spinner4.setAdapter(adapter4);

        String values5[] = {"Download speed of internet", "512kbps", "1Mbps", "2Mbps", "4Mbps", "More than 4Mbps", "other"};
        Spinner spinner5 = (Spinner) v.findViewById(R.id.spinner5);
        ArrayAdapter<String> adapter5 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values5);
        adapter5.setDropDownViewResource(android.R.layout.simple_list_item_checked);
        spinner5.setAdapter(adapter5);


        String values6[] = {"Upload speed of internet", "512kbps", "1Mbps", "2Mbps", "4Mbps", "More than 4Mbps", "other"};
        Spinner spinner6 = (Spinner) v.findViewById(R.id.spinner6);
        ArrayAdapter<String> adapter6 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values6);
        adapter6.setDropDownViewResource(android.R.layout.simple_list_item_checked);
        spinner6.setAdapter(adapter6);

        String values7[] = {"Association with gurukul is", "Primary source of income", "Additional source of income", "Pursue your pession"};
        Spinner spinner7 = (Spinner) v.findViewById(R.id.spinner7);
        ArrayAdapter<String> adapter7 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values7);
        adapter7.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner7.setAdapter(adapter7);

        return v;
    }

    private void checkPermissionsAndOpenFilePicker() {
        String permission = Manifest.permission.READ_EXTERNAL_STORAGE;


        if (ContextCompat.checkSelfPermission(getContext(), permission) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), permission)) {
                showError();
            } else {
                ActivityCompat.requestPermissions(getActivity(), new String[]{permission}, PERMISSIONS_REQUEST_CODE);
            }
        } else {
            openFilePicker();
        }
    }

    private void showError() {
        Toast.makeText(getContext(), "Allow external storage reading", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String permissions[], @NonNull int[] grantResults) {
        switch (requestCode) {
            case PERMISSIONS_REQUEST_CODE: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    openFilePicker();
                } else {
                    showError();
                }
            }
        }
    }

    private void openFilePicker() {
        new MaterialFilePicker()
                .withSupportFragment(this)
                .withRequestCode(FILE_PICKER_REQUEST_CODE)
                .withHiddenFiles(true)
                .start();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FILE_PICKER_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            String path = data.getStringExtra(FilePickerActivity.RESULT_FILE_PATH);

            if (path != null) {
                Log.d("Path (fragment): ", path);
                Toast.makeText(getContext(), "Picked file in fragment: " + path, Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onClick(View view) {
        if (view == next) ;
        usernext();
    }

    private void usernext() {


        String spinner = Spinner.getSelectedItem().toString().trim().toLowerCase();
        String edit = Edit.getText().toString().trim().toLowerCase();
        String edit1 = Edit1.getText().toString().trim().toLowerCase();

        String spinner1 = Spinner1.getSelectedItem().toString().trim().toLowerCase();
        String spinner2 = Spinner2.getSelectedItem().toString().trim().toLowerCase();
        String spinner3 = Spinner3.getSelectedItem().toString().trim().toLowerCase();
        String spinner4 = Spinner4.getSelectedItem().toString().trim().toLowerCase();
        String spinner5 = Spinner5.getSelectedItem().toString().trim().toLowerCase();
        String spinner6 = Spinner6.getSelectedItem().toString().trim().toLowerCase();
        String spinner7 = Spinner7.getSelectedItem().toString().trim().toLowerCase();
        awesomeValidation = new AwesomeValidation(COLORATION);
        awesomeValidation.addValidation(getActivity(), R.id.edit, "[a-zA-Z\\s]+", R.string.err_lname);
        awesomeValidation.addValidation(getActivity(), R.id.edit1, "[a-zA-Z\\s]+", R.string.err_lname);
        awesomeValidation.validate();
        nextclick(edit, edit1);
    }

    private void nextclick(final String edit, final String edit1) {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, REGISTER_URL,
                new com.android.volley.Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(getActivity(), response, Toast.LENGTH_LONG).show();

                    }
                },
                new com.android.volley.Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), error.toString(), Toast.LENGTH_LONG).show();
                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> map = new HashMap<String, String>();
                map.put("Days Available", edit1);
                map.put("occuption", edit);
             /*   map.put("occuption", edit);
                map.put("occuption", edit);
                map.put("occuption", edit);
                map.put("occuption", edit);
                map.put("tog", edit1);
             */   return map;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(getActivity().getApplicationContext());
        requestQueue.add(stringRequest);
    }
}