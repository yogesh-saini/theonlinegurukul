package com.theonlinegurukul.decon.myapplication.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.theonlinegurukul.decon.myapplication.R;

public class Register extends Fragment{
//        implements View.OnClickListener {
    private Button tution;

    //Button sign;
    public Register() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        getActivity().setTitle("Register");
        View v = inflater.inflate(R.layout.fragment_register, container, false);
                    tution =(Button) v.findViewById(R.id.tution);
                    tution.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            FragmentTransaction fr = getFragmentManager().beginTransaction();
                            fr.replace(R.id.frame,new Register_2()).addToBackStack(null).commit();

                        }
                    });
/*
//        sign = (Button) v.findViewById(R.id.signup);
        teacher = (ImageView) v.findViewById(R.id.teacher);
        student = (ImageView) v.findViewById(R.id.student);
        student.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction fr = getFragmentManager().beginTransaction();
                fr.replace(R.id.frame, new Std()).addToBackStack(null);
                fr.commit();

            }
        });
        teacher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction fr = getFragmentManager().beginTransaction();
                fr.replace(R.id.frame, new Teac()).addToBackStack(null).commit();
*/
//                fr.commit();

/*
            }
        });
*/
        return v;
    }
}
                                       /*@Override
                                       public void onClick(View v) {
                                           Intent i;
                                           switch (v.getId()) {
                                               case R.id.student:
                                                   i = new Intent(this, Std.class);
                                                   this.startActivity(i);
                                                   break;
                                               case R.id.teacher:
                                                   i = new Intent(getActivity(), Teac.class);
                                                   startActivity(i);
                                                   break;
                                               default:
                                                   break;

                                           }


                                       }

                                   }



            //                FragmentTransaction fr = getFragmentManager().beginTransaction();
//                fr.replace(R.id.frame, new Student1());
//                fr.commit();
//
//            }
//        });
//        teacher.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
// FragmentTransaction fr = getFragmentManager().beginTransaction();
//                fr.replace(R.id.frame, new Teacher1());
//                fr.commit();
//
//            }
//        });
//        sign.setOnClickListener(this);

        /*Fragment fragment = new Student1();
        FragmentManager fragmentManager =getFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.frame,fragment).commit();*/
//


//        String values[] = {"Profile", "Student", "Teacher"};
//        Spinner spinner = (Spinner) v.findViewById(R.id.spinner);
//        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values);
//        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
//        spinner.setAdapter(adapter);

//    @Override
//    public void onClick(View v) {
//        Fragment fragment = new Student1();
//        FragmentManager fragmentManager =getFragmentManager();
//        fragmentManager.beginTransaction().replace(R.id.frame,fragment).commit();



//        fragment = new Teacher1();
//        fragmentManager = getFragmentManager();
//        fragmentManager.beginTransaction().replace(R.id.frame,fragment).commit();




        //            Fragment fragment = new Student1();
//        FragmentManager fragmentManager =getFragmentManager();
//        fragmentManager.beginTransaction().replace(R.id.frame,fragment).commit();
//        Intent i;
//        switch (v.getId()) {
//            case R.id.student:
//                i = new Intent(getActivity(), Student1.class);
//                getActivity().startActivity(i);
//                break;
//            case R.id.teacher:
//                i = new Intent(getActivity(), Teacher.class);
//                getActivity().startActivity(i);
//                break;
//            default:
//                break;

//        }



//}

