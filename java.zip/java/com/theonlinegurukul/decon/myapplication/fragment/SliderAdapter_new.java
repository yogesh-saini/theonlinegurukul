package com.theonlinegurukul.decon.myapplication.fragment;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.theonlinegurukul.decon.myapplication.R;


public class SliderAdapter_new extends PagerAdapter {

    private Context context;
    private LayoutInflater layoutInflater;

//    private TextView slideHeading, slideDescription;
//    private ImageView slide_imageView;


    public SliderAdapter_new(Context context) {

        this.context = context;
    }

    //     img Array
    public int[] image_slide = {
            R.drawable.it1,
            R.drawable.dis1,
            R.drawable.ptm1,
            R.drawable.yog1,
    };

    // heading Array
    public String[] heading_slide = {
            "IOT|Technology",
            "Disaster Awareness|Training",
            "Parent Partning|counseling",
            "Yoga|Health"
    };

    // description Array
    public String[] description_slide = {
            "The vast network of device connect to network,including smart phones and tablets and almost anything with a sensor on it.",
            "Our objective to spread awareness about disaster management through our workshop,seminar and confrence.",
            "Our goals is to enhance the skills and activity of child, so that childern and family receive high quality growth and development.",
    "This program help strength our body, calm our mind,regain our focus and improve self confidence."
    };


    @Override
    public int getCount() {

        return heading_slide.length;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        layoutInflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.slide_layout, container, false);
        container.addView(view);

        ImageView slide_imageView = view.findViewById(R.id.imageView1);
        TextView slideHeading = view.findViewById(R.id.tvHeading);
        TextView slideDescription = view.findViewById(R.id.tvDescription);

        slide_imageView.setImageResource(image_slide[position]);
        slideHeading.setText(heading_slide[position]);
        slideDescription.setText(description_slide[position]);

        return view;
    }


    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((RelativeLayout) object);
    }

//    @Override
//    public void destroyItem(ViewGroup container, int position, Object object) {
//        View view = (View) object;
//        container.removeView(view);
//    }
//
}


