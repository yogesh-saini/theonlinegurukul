package com.theonlinegurukul.decon.myapplication.fragment;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.theonlinegurukul.decon.myapplication.Basic_info;
import com.theonlinegurukul.decon.myapplication.R;

public class Teac extends Fragment {

    private SectionsPagerAdapter1 mSectionsPagerAdapter;

    private ViewPager mViewPager;


    /*   public static final int PERMISSIONS_REQUEST_CODE = 0;
       public static final int FILE_PICKER_REQUEST_CODE = 1;
   */
    public Teac() {


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        getActivity().setTitle("Teacher");
        View v = inflater.inflate(R.layout.fragment_teac, null);

        mSectionsPagerAdapter   =  new SectionsPagerAdapter1(getChildFragmentManager());
        // Set up the ViewPager with the sections adapter.
        mViewPager = (ViewPager) v.findViewById(R.id.container);
        mViewPager.setAdapter(mSectionsPagerAdapter);

        TabLayout tabLayout = (TabLayout) v.findViewById(R.id.tabs);

        mViewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.addOnTabSelectedListener(new TabLayout.ViewPagerOnTabSelectedListener(mViewPager));

        return v;


    }
}

 class SectionsPagerAdapter1 extends FragmentPagerAdapter {

     public SectionsPagerAdapter1(FragmentManager fm) {
         super(fm);
     }

     @Override
     public Fragment getItem(int position) {
         switch (position) {
             case 0:
                 Basic_info tab = new Basic_info();
                 return tab;
             case 1:
                 Qualification tab1 = new Qualification();
                 return tab1;
             case 2:
                 Pref_class tab2 = new Pref_class();
                 return tab2;
             case 3:
                 Bank_Details tab3 =new Bank_Details();
                 return tab3;
             case 4:
                 Other_upload tab4 = new Other_upload();
                 return tab4;
             default:
                 return null;
         }
     }

     @Override
     public int getCount() {
         return 5;
     }
 }

  /*      Button pickButton = (Button) v.findViewById(R.id.pick_from_activity);
        Button pickButton1 = (Button) v.findViewById(R.id.choose_file);
        pickButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                checkPermissionsAndOpenFilePicker();
            }
        });
              pickButton1.setOnClickListener(new View.OnClickListener() {
                  @Override
                  public void onClick(View view) {
                      checkPermissionsAndOpenFilePicker();
                  }
              });

        String values[] = {"Select Highest Qualification", "11th", "12th", "B.A", "M.A", "B.E", "M.E", "B.Tech", "M.Tech", "B.sc", "M.sc", "BCA", "MCA",
                "BBA", "MBA", "B.Arch", "P.hd", "M.Phill", "BDS", "MDS", "MD", "MBBS", "BPT", "B.Com", "M.Com", "B.pharm", "M.pharm", "CA", "LLB", "ICWA"};
        Spinner spinner = (Spinner) v.findViewById(R.id.spinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        String values1[] = {"Year of Exprience", "Less than a year", "Less than two year", "Less than four year", "More than five year"};
        Spinner spinner2 = (Spinner) v.findViewById(R.id.spinner2);
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values1);
        adapter1.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner2.setAdapter(adapter1);

        String values2[] = {"Primary Subject", "Mathmatics", "Physics", "Chemistry", "Biology", "science", "Computer", "Hindi", "English",
                "Sanskrit", "Social Studies", "German", "French", "EVS"};
        Spinner spinner3 = (Spinner) v.findViewById(R.id.spinner3);
        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values2);
        adapter2.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner3.setAdapter(adapter2);

        String values3[] = {"Secondary Subject", "Mathmatics", "Physics", "Chemistry", "Biology", "science", "Computer", "Hindi", "English",
                "Sanskrit", "Social Studies", "German", "French", "EVS"};
        Spinner spinner4 = (Spinner) v.findViewById(R.id.spinner4);
        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values3);
        adapter3.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner4.setAdapter(adapter3);

        String values4[] = {"Grade Love to Teach", "8 to 9", "9 to 10", "11 to 12(Regular Curriculam)", "11 to 12(JEE Mains Level)", "Other"};
        Spinner spinner5 = (Spinner) v.findViewById(R.id.spinner5);
        ArrayAdapter<String> adapter4 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values4);
        adapter2.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner5.setAdapter(adapter4);

        String values5[] = {"Boards", "CBSE", "ICSE", "IB", "IGCSE", "Other"};
        Spinner spinner6 = (Spinner) v.findViewById(R.id.spinner6);
        ArrayAdapter<String> adapter5 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values5);
        adapter2.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner6.setAdapter(adapter5);

        String values6[] = {"Available Time Weekdays", "0 hour", "1 hour", "2 hour", "3 hour", "4 hour", "5 hour", "6 hour", "7 hour", "8 hour"};
        Spinner spinner7 = (Spinner) v.findViewById(R.id.spinner7);
        ArrayAdapter<String> adapter6 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values6);
        adapter2.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner7.setAdapter(adapter6);

        String values7[] = {"Available Timing", "6-7Am", "7-8Am", "8-9Am", "9-10Am", "10-11Am", "11-12Am", "2-3Pm", "3-4Pm", "4-5Pm", "5-6Pm",
                "6-7Pm", "7-8Pm", "8-9Pm"};
        Spinner spinner8 = (Spinner) v.findViewById(R.id.spinner8);
        ArrayAdapter<String> adapter7 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values7);
        adapter7.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner8.setAdapter(adapter7);

        String values8[] = {"Current Occupation", "Full Time Teacher", "Freelancer", "Working Professional", "College Student",
                "Not Working", "Other"};
        Spinner spinner9 = (Spinner) v.findViewById(R.id.spinner9);
        ArrayAdapter<String> adapter8 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values8);
        adapter8.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner9.setAdapter(adapter8);

        String values9[] = {"Type of Connection", "Brodband", "Wifi", "Dongle", "Mobile",
                "Cable", "Other"};
        Spinner spinner10 = (Spinner) v.findViewById(R.id.spinner10);
        ArrayAdapter<String> adapter9 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values9);
        adapter8.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner10.setAdapter(adapter9);

        String values10[] = {"Download Speed of Internet Connection", "512 kbps", "1 Mbps", "2 Mbps", "4 Mbps",
                "More than 4 Mbps", "Other"};
        Spinner spinner11 = (Spinner) v.findViewById(R.id.spinner11);
        ArrayAdapter<String> adapter10 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values10);
        adapter8.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner11.setAdapter(adapter10);

        String values11[] = {"Upload Speed of Internet Connection", "512 kbps", "1 Mbps", "2 Mbps", "4 Mbps",
                "More than 4 Mbps", "Other"};
        Spinner spinner12 = (Spinner) v.findViewById(R.id.spinner12);
        ArrayAdapter<String> adapter11 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values11);
        adapter8.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner12.setAdapter(adapter11);

*//*
        String values12[] = {"Upload Speed of Internet Connection", "512 kbps", "1 Mbps", "2 Mbps", "4 Mbps",
                "More than 4 Mbps", "Other"};
        Spinner spinner13 = (Spinner) v.findViewById(R.id.spinner13);
        ArrayAdapter<String> adapter12 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values12);
        adapter12.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner13.setAdapter(adapter12);
*//*

        String values13[] = {"Association with gurukul is", "Primary Source of income", "Additional Source of income", "Pursue your passion",
                "Other"};
        Spinner spinner14 = (Spinner) v.findViewById(R.id.spinner14);
        ArrayAdapter<String> adapter13 = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values13);
        adapter13.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner14.setAdapter(adapter13);


        return v;
    }

    private void checkPermissionsAndOpenFilePicker() {
        String permission = Manifest.permission.READ_EXTERNAL_STORAGE;

        if (ContextCompat.checkSelfPermission(getContext(), permission) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), permission)) {
                showError();
            } else {
                ActivityCompat.requestPermissions(getActivity(), new String[]{permission}, PERMISSIONS_REQUEST_CODE);
            }
        } else {
            openFilePicker();
        }
    }

    private void showError() {
        Toast.makeText(getContext(), "Allow external storage reading", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String permissions[], @NonNull int[] grantResults) {
        switch (requestCode) {
            case PERMISSIONS_REQUEST_CODE: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    openFilePicker();
                } else {
                    showError();
                }
            }
        }
    }

    private void openFilePicker() {
        new MaterialFilePicker()
                .withSupportFragment(this)
                .withRequestCode(FILE_PICKER_REQUEST_CODE)
                .withHiddenFiles(true)
                .start();
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FILE_PICKER_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            String path = data.getStringExtra(FilePickerActivity.RESULT_FILE_PATH);

            if (path != null) {
                Log.d("Path (fragment): ", path);
                Toast.makeText(getContext(), "Picked file in fragment: " + path, Toast.LENGTH_LONG).show();
            }
        }
    }


    public void addToBackStack() {
        if (getFragmentManager().getBackStackEntryCount() == 0) {
            getActivity().finish();
        } else {
            getFragmentManager().popBackStack();
        }

    }
}

*/