package com.theonlinegurukul.decon.myapplication.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.theonlinegurukul.decon.myapplication.R;
public class Register_2 extends Fragment{

private ImageView student, teacher;

//Button sign;
public Register_2() {

        }

@Override
public View onCreateView(LayoutInflater inflater, ViewGroup container,
        Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        getActivity().setTitle("Register");
        View v = inflater.inflate(R.layout.fragment_register_2, container, false);

//        sign = (Button) v.findViewById(R.id.signup);
        teacher = (ImageView) v.findViewById(R.id.teacher);
        student = (ImageView) v.findViewById(R.id.student);
        student.setOnClickListener(new View.OnClickListener() {
@Override
public void onClick(View view) {
        FragmentTransaction fr = getFragmentManager().beginTransaction();
        fr.replace(R.id.frame, new Std()).addToBackStack(null);
        fr.commit();

        }
        });
        teacher.setOnClickListener(new View.OnClickListener() {
@Override
public void onClick(View view) {
        FragmentTransaction fr = getFragmentManager().beginTransaction();
        fr.replace(R.id.frame, new Teac()).addToBackStack(null).commit();
//                fr.commit();

        }
        });
        return v;
        }
        }