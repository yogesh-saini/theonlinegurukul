package com.theonlinegurukul.decon.myapplication.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;

import com.theonlinegurukul.decon.myapplication.R;
import com.theonlinegurukul.decon.myapplication.Teacher_dashboard;

public class Teach1 extends Fragment implements View.OnClickListener{
    CheckBox checkpass;
    private EditText inputEmail;
    private EditText inputPassword;

    Button signin;
    TextView gor;

    public Teach1() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        getActivity().setTitle("Teacher");
        View v = inflater.inflate(R.layout.fragment_teach1, container, false);
        inputEmail = (EditText) v.findViewById(R.id.email);
        inputPassword = (EditText) v.findViewById(R.id.password);

        signin = (Button) v.findViewById(R.id.signin_t);
        gor = (TextView) v.findViewById(R.id.gor_t);



        checkpass = (CheckBox) v.findViewById(R.id.Checkpass);
        // Progress dialog
        // pDialog = new ProgressDialog(this);
        //pDialog.setCancelable(false);


        checkpass.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {


            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {

                if (!isChecked) {
                    // show password
                    inputPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                } else {
                    // hide password
                    inputPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
            }
        });







        signin.setOnClickListener(this);
//             signin.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent i;
//                Toast.makeText(getActivity(),"sign in",Toast.LENGTH_SHORT).show();
//            }
//        });

        gor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction fr = getFragmentManager().beginTransaction();
                fr.replace(R.id.frame, new Teac()).addToBackStack(null).commit();
            }
        });
        return v;

    }

    @Override
    public void onClick(View view) {
        Intent i;
        switch (view.getId()) {
            case R.id.signin_t:
                i = new Intent(getActivity(), Teacher_dashboard.class);
                getActivity().startActivity(i);
                break;
            default:

        }
    }
}
//     @Override
//    public void onClick(View view) {
//        Intent i;
//        switch (view.getId()) {
//            case R.id.signin:
//                i = new Intent(getActivity(), Student_dashboard.class);
//                getActivity().startActivity(i);
//                break;
//            default:
//
//        }
//    }
//}