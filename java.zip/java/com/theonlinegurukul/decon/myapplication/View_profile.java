package com.theonlinegurukul.decon.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.theonlinegurukul.decon.myapplication.fragment.stud1;

public class View_profile extends AppCompatActivity {
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_profile);


    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.example_menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu:
                Intent intent = new Intent(View_profile.this, Upload_Avatar.class);
//           Toast.makeText(this, "item1 select", Toast.LENGTH_SHORT);
                startActivity(intent);
        }
        switch (item.getItemId()){
            case R.id.menu1:
                Intent intent = new Intent(View_profile.this, Edit_profile.class);
                startActivity(intent);

        }
        switch (item.getItemId()){
            case R.id.menu2:
                Intent intent = new Intent(View_profile.this, View_profile.class);
                startActivity(intent);

        }
        switch (item.getItemId()){
            case R.id.menu3:
                Intent intent = new Intent(View_profile.this, stud1.class);
                startActivity(intent);

        }



        return super.onOptionsItemSelected(item);





    }
}



